#include "ddgi_common.hlsli"

// DDGI step 1: trace one ray per octahedral texel and blend into history.
//
// Each texel owns a fixed octahedral direction (teaching-lite: no per-frame
// ray rotation). The SDF march returns radiance (direct diffuse at the hit,
// sky on a miss) and hit distance; both atlases blend against last frame's
// imported history with hysteresis. dimensions.x = frameIndex; frame 0 does
// a full overwrite so validation runs deterministically.
//
// This is the scheme with real history reads - the whole point of DDGI's
// hysteresis is temporal amortization, so the workbench does not pretend
// otherwise (every other scheme keeps history reads = 0).

Texture2D<float4> gPrevRadiance : register(t0);
Texture2D<float4> gPrevMoments : register(t1);
RWTexture2D<float4> gRadianceAtlas : register(u0);
RWTexture2D<float4> gMomentsAtlas : register(u1);

static const float kHysteresis = 0.88;

[numthreads(8, 8, 1)]
void csTrace(uint3 id : SV_DispatchThreadID) {
    uint2 atlasSize = uint2(
        kProbeGridSize.x * kProbeGridSize.z * kDDGIOctSize,
        kProbeGridSize.y * kDDGIOctSize);
    if (any(id.xy >= atlasSize))
        return;

    uint2 tile = id.xy / kDDGIOctSize;
    uint2 oct = id.xy % kDDGIOctSize;
    uint3 probeIndex = uint3(tile.x % kProbeGridSize.x,
                             tile.y,
                             tile.x / kProbeGridSize.x);
    float3 origin = probeWorldPosition(probeIndex);
    float3 direction = ddgiOctDecode((float2(oct) + 0.5) / kDDGIOctSize);

    float3 radiance;
    float hitDistance = kDDGIMaxRayDistance;
    {
        float travelled = 0.03;
        bool hit = false;
        [loop]
        for (uint step = 0;
             step < 72 && travelled < kDDGIMaxRayDistance; ++step) {
            float3 position = origin + direction * travelled;
            SceneSample scene = sampleAnalyticScene(position);
            if (scene.distance < 0.008) {
                float3 normal = sceneNormal(position);
                float3 surface = position - normal * scene.distance;
                radiance = evaluateDirectDiffuse(
                    surface, normal, scene.albedo);
                hitDistance = travelled;
                hit = true;
                break;
            }
            travelled += clamp(scene.distance * 0.78, 0.008, 0.30);
        }
        if (!hit)
            radiance = skyColor(direction);
    }

    float blend = gGI.dimensions.x == 0 ? 0.0 : kHysteresis;
    float4 previousRadiance = gPrevRadiance.Load(int3(id.xy, 0));
    float4 previousMoments = gPrevMoments.Load(int3(id.xy, 0));
    float3 blendedRadiance = lerp(radiance, previousRadiance.rgb, blend);
    float2 moments = float2(hitDistance, hitDistance * hitDistance);
    float2 blendedMoments = lerp(moments, previousMoments.xy, blend);

    gRadianceAtlas[id.xy] = float4(blendedRadiance, 1.0);
    gMomentsAtlas[id.xy] = float4(blendedMoments, 0.0, 1.0);
}
