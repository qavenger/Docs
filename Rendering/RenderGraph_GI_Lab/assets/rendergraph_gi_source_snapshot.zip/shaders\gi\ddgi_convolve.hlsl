#include "ddgi_common.hlsli"

// DDGI step 2: cosine-convolve the radiance atlas into an irradiance atlas.
//
// Each irradiance texel owns an octahedral *normal* direction; its value is
// the cosine-weighted integral of the probe's 64 radiance texels. Equal
// solid angle per octahedral texel is assumed (4*pi / 64) - the honest
// teaching-lite simplification instead of per-texel solid-angle weights.

Texture2D<float4> gRadianceAtlas : register(t0);
RWTexture2D<float4> gIrradianceAtlas : register(u0);

[numthreads(8, 8, 1)]
void csConvolve(uint3 id : SV_DispatchThreadID) {
    uint2 atlasSize = uint2(
        kProbeGridSize.x * kProbeGridSize.z * kDDGIOctSize,
        kProbeGridSize.y * kDDGIOctSize);
    if (any(id.xy >= atlasSize))
        return;

    uint2 tileOrigin = (id.xy / kDDGIOctSize) * kDDGIOctSize;
    uint2 oct = id.xy % kDDGIOctSize;
    float3 normal = ddgiOctDecode((float2(oct) + 0.5) / kDDGIOctSize);

    const float solidAngle = 4.0 * kPi / (kDDGIOctSize * kDDGIOctSize);
    float3 irradiance = 0.0;
    [loop]
    for (uint y = 0; y < kDDGIOctSize; ++y) {
        [loop]
        for (uint x = 0; x < kDDGIOctSize; ++x) {
            float3 direction = ddgiOctDecode(
                (float2(x, y) + 0.5) / kDDGIOctSize);
            float cosine = dot(normal, direction);
            if (cosine <= 0.0)
                continue;
            float3 radiance = gRadianceAtlas.Load(
                int3(tileOrigin + uint2(x, y), 0)).rgb;
            irradiance += radiance * (cosine * solidAngle);
        }
    }
    gIrradianceAtlas[id.xy] = float4(irradiance, 1.0);
}
