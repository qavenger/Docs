#pragma once

#include "probe_common.hlsli"

// DDGI teaching-lite shared layout.
//
// Same 8x4x8 probe grid as the SH probe scheme, but stored the DDGI way:
// per-probe octahedral tiles in a 2D atlas, with a second atlas carrying
// distance moments (mean, mean^2) for Chebyshev visibility, and a real
// temporal hysteresis blend against last frame's atlases. This is the part
// of DDGI the docs module teaches; what stays out (and is said out loud):
// no per-frame ray rotation / importance redistribution, no border texels
// (we clamp inside the tile instead), no probe relocation or scrolling,
// rays come from the analytic SDF instead of hardware RT.
//
// Atlas layout: tile (x + z * gridX, y), texel = tile * kDDGIOctSize + oct.
//   width  = gridX * gridZ * kDDGIOctSize = 8*8*8 = 512
//   height = gridY * kDDGIOctSize         = 4*8   = 32

static const uint kDDGIOctSize = 8;
static const float kDDGIMaxRayDistance = 12.0;

uint2 ddgiTileOrigin(uint3 probeIndex) {
    return uint2((probeIndex.x + probeIndex.z * kProbeGridSize.x) *
                     kDDGIOctSize,
                 probeIndex.y * kDDGIOctSize);
}

// Standard octahedral mapping (Cigolle et al.), tile-local uv in [0,1].
float3 ddgiOctDecode(float2 uv) {
    float2 f = uv * 2.0 - 1.0;
    float3 direction = float3(f.x, 1.0 - abs(f.x) - abs(f.y), f.y);
    if (direction.y < 0.0) {
        float2 sign2 = float2(f.x >= 0.0 ? 1.0 : -1.0,
                              f.y >= 0.0 ? 1.0 : -1.0);
        float2 folded = (1.0 - abs(float2(f.y, f.x))) * sign2;
        direction.x = folded.x;
        direction.z = folded.y;
    }
    return normalize(direction);
}

float2 ddgiOctEncode(float3 direction) {
    float3 a = abs(direction);
    float norm = a.x + a.y + a.z;
    float2 f = float2(direction.x, direction.z) / max(norm, 1e-5);
    if (direction.y < 0.0) {
        float2 sign2 = float2(f.x >= 0.0 ? 1.0 : -1.0,
                              f.y >= 0.0 ? 1.0 : -1.0);
        f = (1.0 - abs(float2(f.y, f.x))) * sign2;
    }
    return f * 0.5 + 0.5;
}

// Tile-local texel for a direction, clamped inside the tile (teaching-lite
// replacement for DDGI's duplicated border texels).
uint2 ddgiDirectionTexel(uint3 probeIndex, float3 direction) {
    float2 uv = ddgiOctEncode(direction);
    uint2 oct = uint2(clamp(uv * kDDGIOctSize, 0.0,
                            float(kDDGIOctSize) - 1.0));
    return ddgiTileOrigin(probeIndex) + oct;
}
