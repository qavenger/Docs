#pragma once

#include "voxel_gi_common.hlsli"

// Flatland Radiance Cascades over a horizontal slice of the analytic scene.
//
// The docs module teaches RC with mature 2D interval/merge experiments and
// explicitly marks full 3D RC as a boundary; the native scheme follows the
// same honesty: this is the real cascade algorithm (cast + merge + resolve)
// in two dimensions, not a fake 3D implementation.
//
// The 2D scene IS the 3D analytic scene sampled at y = kRCSliceHeight, so
// the walls, the box and the sphere all cast flatland shadows. The animated
// point light becomes a disk emitter in the slice; directly lit occluder
// boundaries re-emit their bounce color, which is what turns the merged
// fluence field into actual one-bounce GI.
//
// Cascade layout (classic RC invariant - every atlas is the same size):
//   C0: 64x64 probes x  4 directions (2x2 tile)  -> 128x128
//   C1: 32x32 probes x 16 directions (4x4 tile)  -> 128x128
//   C2: 16x16 probes x 64 directions (8x8 tile)  -> 128x128
//   C3:  8x8  probes x 256 directions (16x16)    -> 128x128
// Probe-major layout: texel = probe.xy * sqrtDirs + dirTile.xy.

static const float kRCSliceHeight = 0.9;
// Domain hugs the outer wall faces (walls end at |x|,|z| = 3.92) so the
// preview is wall-to-wall room instead of black out-of-scene margin.
static const float2 kRCDomainMin = float2(-3.95, -3.95);
static const float kRCDomainExtent = 7.9;
static const uint kRCAtlasSize = 128;
static const uint kRCCascadeCount = 4;
static const float kRCBaseInterval = 0.35;
static const float kRCLightRadius = 0.34;

uint rcProbeCount(uint cascade) { return 64u >> cascade; }
uint rcSqrtDirections(uint cascade) { return 2u << cascade; }
uint rcDirectionCount(uint cascade) {
    uint sqrtDirections = rcSqrtDirections(cascade);
    return sqrtDirections * sqrtDirections;
}

// Geometric interval [start, end) covered by one cascade.
float rcIntervalStart(uint cascade) {
    return kRCBaseInterval * (pow(4.0, (float)cascade) - 1.0) / 3.0;
}
float rcIntervalEnd(uint cascade) {
    return kRCBaseInterval * (pow(4.0, (float)cascade + 1.0) - 1.0) / 3.0;
}

float2 rcProbeWorld(uint cascade, uint2 probeIndex) {
    float2 t = (float2(probeIndex) + 0.5) / rcProbeCount(cascade);
    return kRCDomainMin + t * kRCDomainExtent;
}

float2 rcDirection(uint cascade, uint directionIndex) {
    float angle = (float(directionIndex) + 0.5) * 2.0 * kPi /
                  rcDirectionCount(cascade);
    return float2(cos(angle), sin(angle));
}

// 2D slice of the 3D scene.
SceneSample rcSliceScene(float2 planePosition) {
    return sampleAnalyticScene(
        float3(planePosition.x, kRCSliceHeight, planePosition.y));
}

float2 rcLightCenter() {
    return gGI.lightPositionIntensity.xz;
}

float rcEmitterDistance(float2 planePosition) {
    return length(planePosition - rcLightCenter()) - kRCLightRadius;
}

// In-plane direct lighting used to color re-emitting occluder boundaries.
float3 rcDirectLight2D(float2 surfacePosition, float2 surfaceNormal) {
    float2 toLight = rcLightCenter() - surfacePosition;
    float distanceSquared = max(dot(toLight, toLight), 0.04);
    float2 lightDirection = toLight * rsqrt(distanceSquared);
    float cosine = saturate(dot(surfaceNormal, lightDirection));
    float attenuation = 1.0 / (1.0 + 0.32 * distanceSquared);

    // 2D shadow march toward the emitter.
    float maximumDistance = sqrt(distanceSquared) - kRCLightRadius;
    float travelled = 0.05;
    float visibility = 1.0;
    [loop]
    for (uint step = 0; step < 32 && travelled < maximumDistance - 0.03;
         ++step) {
        float2 position = surfacePosition + lightDirection * travelled;
        float sceneDistance = rcSliceScene(position).distance;
        if (sceneDistance < 0.012) {
            visibility = 0.0;
            break;
        }
        travelled += clamp(sceneDistance * 0.8, 0.012, 0.30);
    }
    return gGI.lightColorTime.rgb *
           (gGI.lightPositionIntensity.w * 0.35 * attenuation * cosine *
            visibility);
}

float2 rcSliceNormal(float2 planePosition) {
    const float epsilon = 0.014;
    float dx = rcSliceScene(planePosition + float2(epsilon, 0)).distance -
               rcSliceScene(planePosition - float2(epsilon, 0)).distance;
    float dz = rcSliceScene(planePosition + float2(0, epsilon)).distance -
               rcSliceScene(planePosition - float2(0, epsilon)).distance;
    float2 normal = float2(dx, dz);
    float lengthSquared = dot(normal, normal);
    return lengthSquared > 1e-8 ? normal * rsqrt(lengthSquared)
                                : float2(0.0, 1.0);
}
