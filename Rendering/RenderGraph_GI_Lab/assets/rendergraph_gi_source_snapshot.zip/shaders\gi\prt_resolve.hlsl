#include "prt_common.hlsli"

// PRT step 3: relight. indirect = A_l * (T_lm * L_lm) evaluated at n.
//
// The per-coefficient product T*L is the band-limited PRT approximation of
// "environment radiance masked by local visibility"; A_l then convolves
// with the cosine lobe (A0 = pi, A1 = 2pi/3). Transfer comes from the 8
// surrounding probes with trilinear + soft backface weights.
//
// View modes (cameraPositionMode.w):
//   0 = final (direct point light + PRT environment indirect)
//   1 = transfer BYPASSED (environment applied unmasked - compare with 0
//       to see exactly what caching the transfer operator buys)
//   2 = transfer-probe field slice (T0 at probe height)
//   3 = PRT indirect only (sky black)

Texture3D<float4> gTransfer : register(t0);
Texture2D<float4> gEnvironmentSH : register(t1);
RWTexture2D<float4> gResolveTarget : register(u0);

float4 sampleTransfer(float3 position, float3 normal, bool useTransfer) {
    if (!useTransfer) {
        // Unmasked visibility: V == 1 everywhere. Only the DC term
        // survives projection: T0 = integral(Y00) = 2*sqrt(pi).
        return float4(2.0 * sqrt(kPi), 0.0, 0.0, 0.0);
    }
    float3 gridCoordinate =
        (position - kProbeGridMin) / kProbeGridExtent *
        float3(kProbeGridSize) - 0.5;
    float3 clamped = clamp(gridCoordinate, 0.0,
                           float3(kProbeGridSize) - 1.001);
    uint3 baseIndex = uint3(clamped);
    float3 fraction = saturate(clamped - float3(baseIndex));

    float4 transfer = 0.0;
    float weightSum = 0.0;
    [unroll]
    for (uint corner = 0; corner < 8; ++corner) {
        uint3 offset = uint3(corner & 1, (corner >> 1) & 1, (corner >> 2) & 1);
        uint3 probeIndex = min(baseIndex + offset, kProbeGridSize - 1);
        float3 trilinear = lerp(1.0 - fraction, fraction, float3(offset));
        float weight = trilinear.x * trilinear.y * trilinear.z;
        if (weight < 1e-4)
            continue;
        float3 probeDirection = normalize(
            probeWorldPosition(probeIndex) - position);
        float facing = saturate(dot(normal, probeDirection) * 0.5 + 0.55);
        weight *= facing * facing;
        transfer += gTransfer.Load(int4(probeIndex, 0)) * weight;
        weightSum += weight;
    }
    return weightSum > 1e-4 ? transfer / weightSum : 0.0;
}

float3 prtIrradiance(float4 transfer, float3 normal) {
    float4 basis = shEvaluateL1(normal);
    float3 irradiance = 0.0;
    // Per-coefficient product of transfer (scalar) and environment (RGB),
    // then cosine-lobe convolution weights A0 = pi, A1 = 2pi/3.
    float3 l0 = gEnvironmentSH.Load(int3(0, 0, 0)).rgb;
    float3 l1x = gEnvironmentSH.Load(int3(1, 0, 0)).rgb;
    float3 l1y = gEnvironmentSH.Load(int3(2, 0, 0)).rgb;
    float3 l1z = gEnvironmentSH.Load(int3(3, 0, 0)).rgb;
    irradiance += 3.14159265 * (transfer.x * l0) * basis.x;
    irradiance += 2.09439510 * ((transfer.y * l1x) * basis.y +
                                (transfer.z * l1y) * basis.z +
                                (transfer.w * l1z) * basis.w);
    return max(irradiance, 0.0);
}

[numthreads(8, 8, 1)]
void csResolve(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float debugMode = gGI.cameraPositionMode.w;
    if (debugMode > 1.5 && debugMode < 2.5) {
        // Transfer field slice: T0 = how open to the environment each
        // location is. Bright = sees lots of sky, dark = enclosed.
        float3 slicePosition = kProbeGridMin + float3(
            uv.x * kProbeGridExtent.x,
            kProbeGridExtent.y * 0.38,
            (1.0 - uv.y) * kProbeGridExtent.z);
        float4 transfer = sampleTransfer(
            slicePosition, float3(0, 1, 0), true);
        gResolveTarget[id.xy] = float4(transfer.xxx * 0.16, 1.0);
        return;
    }

    CameraBasis camera = makeWorkbenchCamera();
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);
    float3 direction = cameraRayDirection(camera, uv, aspect);

    float3 hitPosition;
    float3 hitNormal;
    float3 albedo;
    float3 color;
    if (!traceCameraRay(camera.position, direction,
                        hitPosition, hitNormal, albedo)) {
        color = debugMode > 2.5 ? 0.0 : skyColor(direction);
    } else {
        bool useTransfer = !(debugMode > 0.5 && debugMode < 1.5);
        float3 direct = evaluateDirectDiffuse(hitPosition, hitNormal, albedo);
        float4 transfer = sampleTransfer(
            hitPosition + hitNormal * 0.04, hitNormal, useTransfer);
        float3 indirect = albedo *
            prtIrradiance(transfer, hitNormal) / kPi;
        color = debugMode > 2.5
            ? indirect * 1.9
            : direct + indirect + albedo * 0.015;
    }
    gResolveTarget[id.xy] = float4(color, 1.0);
}
