#include "probe_common.hlsli"

// Probe resolve: shade with the 8 surrounding probes of the shading point.
//
// The teaching contrast lives in the weights:
//   - "leaky" mode uses pure trilinear interpolation, which happily reads
//     probes on the wrong side of a wall (classic probe light leak);
//   - the default mode multiplies each probe weight by an SDF segment
//     visibility test plus a soft backface term, which is what visibility-
//     aware probe systems (DDGI et al.) approximate with depth moments.
// This workbench uses ground-truth SDF visibility instead of Chebyshev
// moments and says so; octahedral depth atlases stay a documented boundary.
//
// View modes (cameraPositionMode.w):
//   0 = final, visibility-weighted
//   1 = final, leaky trilinear (compare against mode 0!)
//   2 = irradiance-field slice at probe height (n = +Y)
//   3 = indirect only (visibility-weighted)

Texture3D<float4> gProbeSHRed : register(t0);
Texture3D<float4> gProbeSHGreen : register(t1);
Texture3D<float4> gProbeSHBlue : register(t2);
RWTexture2D<float4> gResolveTarget : register(u0);

struct ProbeIrradiance {
    float3 value;
    float weightSum;
};

ProbeIrradiance sampleProbes(float3 position, float3 normal,
                             bool useVisibility) {
    float3 gridCoordinate =
        (position - kProbeGridMin) / kProbeGridExtent *
        float3(kProbeGridSize) - 0.5;
    float3 clamped = clamp(gridCoordinate, 0.0,
                           float3(kProbeGridSize) - 1.001);
    uint3 baseIndex = uint3(clamped);
    float3 fraction = saturate(clamped - float3(baseIndex));

    ProbeIrradiance result;
    result.value = 0.0;
    result.weightSum = 0.0;

    [unroll]
    for (uint corner = 0; corner < 8; ++corner) {
        uint3 offset = uint3(corner & 1, (corner >> 1) & 1, (corner >> 2) & 1);
        uint3 probeIndex = min(baseIndex + offset, kProbeGridSize - 1);
        float3 trilinear = lerp(1.0 - fraction, fraction, float3(offset));
        float weight = trilinear.x * trilinear.y * trilinear.z;
        if (weight < 1e-4)
            continue;

        float3 probePosition = probeWorldPosition(probeIndex);
        if (useVisibility) {
            float3 toProbe = probePosition - position;
            float3 probeDirection = normalize(toProbe);
            // Soft backface: probes behind the surface contribute little.
            float facing = saturate(dot(normal, probeDirection) * 0.5 + 0.55);
            weight *= facing * facing;
            // Ground-truth SDF occlusion between surface and probe.
            if (!segmentVisible(position + normal * 0.05, probePosition))
                weight *= 0.015;
        }
        if (weight < 1e-5)
            continue;

        float4 shRed = gProbeSHRed.Load(int4(probeIndex, 0));
        float4 shGreen = gProbeSHGreen.Load(int4(probeIndex, 0));
        float4 shBlue = gProbeSHBlue.Load(int4(probeIndex, 0));
        float3 irradiance = float3(shIrradiance(shRed, normal),
                                   shIrradiance(shGreen, normal),
                                   shIrradiance(shBlue, normal));
        result.value += irradiance * weight;
        result.weightSum += weight;
    }
    if (result.weightSum > 1e-4)
        result.value /= result.weightSum;
    return result;
}

[numthreads(8, 8, 1)]
void csResolve(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float debugMode = gGI.cameraPositionMode.w;
    if (debugMode > 1.5 && debugMode < 2.5) {
        // Horizontal irradiance-field slice through the probe volume.
        float3 slicePosition = kProbeGridMin + float3(
            uv.x * kProbeGridExtent.x,
            kProbeGridExtent.y * 0.38,
            (1.0 - uv.y) * kProbeGridExtent.z);
        ProbeIrradiance field =
            sampleProbes(slicePosition, float3(0, 1, 0), false);
        gResolveTarget[id.xy] = float4(field.value * 0.55, 1.0);
        return;
    }

    CameraBasis camera = makeWorkbenchCamera();
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);
    float3 direction = cameraRayDirection(camera, uv, aspect);

    float3 hitPosition;
    float3 hitNormal;
    float3 albedo;
    float3 color;
    if (!traceCameraRay(camera.position, direction,
                        hitPosition, hitNormal, albedo)) {
        // Indirect-only keeps the sky black so validation measures the
        // actual probe gather, not the sky gradient.
        color = debugMode > 2.5 ? 0.0 : skyColor(direction);
    } else {
        bool useVisibility = !(debugMode > 0.5 && debugMode < 1.5);
        float3 direct = evaluateDirectDiffuse(hitPosition, hitNormal, albedo);
        ProbeIrradiance probes = sampleProbes(
            hitPosition + hitNormal * 0.04, hitNormal, useVisibility);
        // The probes store full incident radiance (sky + direct bounce), so
        // the indirect scale stays modest to avoid double counting the sun...
        // there is no sun here, but the same reasoning applies to the sky.
        float3 indirect = albedo * probes.value * 0.55;
        color = debugMode > 2.5
            ? indirect * 1.9
            : direct + indirect + albedo * 0.015;
    }
    gResolveTarget[id.xy] = float4(color, 1.0);
}
