#include "ddgi_common.hlsli"

// DDGI step 3: shade with the 8 surrounding probes.
//
// Weights = trilinear x soft backface x Chebyshev visibility from the
// distance-moments atlas - the actual DDGI leak-suppression mechanism (mode
// 1 turns Chebyshev off so the leak it prevents becomes visible).
//
// View modes (cameraPositionMode.w):
//   0 = final (direct + probe irradiance, Chebyshev on)
//   1 = final with Chebyshev OFF (leak comparison)
//   2 = raw radiance atlas (the data structure, stretched to screen)
//   3 = indirect only (Chebyshev on, sky black)

Texture2D<float4> gIrradianceAtlas : register(t0);
Texture2D<float4> gMomentsAtlas : register(t1);
Texture2D<float4> gRadianceAtlas : register(t2);
RWTexture2D<float4> gResolveTarget : register(u0);

float3 sampleDDGIIrradiance(float3 position, float3 normal,
                            bool useChebyshev) {
    float3 gridCoordinate =
        (position - kProbeGridMin) / kProbeGridExtent *
        float3(kProbeGridSize) - 0.5;
    float3 clamped = clamp(gridCoordinate, 0.0,
                           float3(kProbeGridSize) - 1.001);
    uint3 baseIndex = uint3(clamped);
    float3 fraction = saturate(clamped - float3(baseIndex));

    float3 irradiance = 0.0;
    float weightSum = 0.0;
    [unroll]
    for (uint corner = 0; corner < 8; ++corner) {
        uint3 offset = uint3(corner & 1, (corner >> 1) & 1, (corner >> 2) & 1);
        uint3 probeIndex = min(baseIndex + offset, kProbeGridSize - 1);
        float3 trilinear = lerp(1.0 - fraction, fraction, float3(offset));
        float weight = trilinear.x * trilinear.y * trilinear.z;
        if (weight < 1e-4)
            continue;

        float3 probePosition = probeWorldPosition(probeIndex);
        float3 toProbe = probePosition - position;
        float probeDistance = length(toProbe);
        float3 probeDirection = toProbe / max(probeDistance, 1e-4);

        // Soft backface, same shape as the SH probe scheme.
        float facing = saturate(dot(normal, probeDirection) * 0.5 + 0.55);
        weight *= facing * facing;

        if (useChebyshev && probeDistance > 1e-3) {
            // The probe recorded what it sees toward the shading point.
            float2 moments = gMomentsAtlas.Load(
                int3(ddgiDirectionTexel(probeIndex, -probeDirection), 0)).xy;
            float variance = max(moments.y - moments.x * moments.x, 1e-4);
            if (probeDistance > moments.x) {
                float delta = probeDistance - moments.x;
                float chebyshev = variance / (variance + delta * delta);
                weight *= max(chebyshev * chebyshev * chebyshev, 0.01);
            }
        }
        if (weight < 1e-5)
            continue;

        float3 probeIrradiance = gIrradianceAtlas.Load(
            int3(ddgiDirectionTexel(probeIndex, normal), 0)).rgb;
        irradiance += probeIrradiance * weight;
        weightSum += weight;
    }
    return weightSum > 1e-4 ? irradiance / weightSum : 0.0;
}

[numthreads(8, 8, 1)]
void csResolve(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float debugMode = gGI.cameraPositionMode.w;
    if (debugMode > 1.5 && debugMode < 2.5) {
        uint2 atlasSize = uint2(
            kProbeGridSize.x * kProbeGridSize.z * kDDGIOctSize,
            kProbeGridSize.y * kDDGIOctSize);
        uint2 texel = uint2(uv * atlasSize);
        float3 radiance = gRadianceAtlas.Load(int3(texel, 0)).rgb;
        gResolveTarget[id.xy] = float4(radiance * 1.6, 1.0);
        return;
    }

    CameraBasis camera = makeWorkbenchCamera();
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);
    float3 direction = cameraRayDirection(camera, uv, aspect);

    float3 hitPosition;
    float3 hitNormal;
    float3 albedo;
    float3 color;
    if (!traceCameraRay(camera.position, direction,
                        hitPosition, hitNormal, albedo)) {
        color = debugMode > 2.5 ? 0.0 : skyColor(direction);
    } else {
        bool useChebyshev = !(debugMode > 0.5 && debugMode < 1.5);
        float3 direct = evaluateDirectDiffuse(hitPosition, hitNormal, albedo);
        float3 irradiance = sampleDDGIIrradiance(
            hitPosition + hitNormal * 0.04, hitNormal, useChebyshev);
        float3 indirect = albedo * irradiance * (0.55 / kPi);
        color = debugMode > 2.5
            ? indirect * 1.9
            : direct + indirect + albedo * 0.015;
    }
    gResolveTarget[id.xy] = float4(color, 1.0);
}
