#include "voxel_gi_common.hlsli"

// SSGI step 1: build the camera GBuffer the screen-space passes consume.
// Primary visibility uses the shared workbench camera; the SDF march plays
// the role a raster PreZ/BasePass would play with triangle geometry.
//
// Layout (all RGBA16_FLOAT):
//   PositionDepth : xyz world position, w view-forward depth (0 = sky)
//   Normal        : xyz world normal,   w hit flag
//   Albedo        : rgb surface albedo
//   Direct        : rgb direct lighting for hits, sky radiance for misses

RWTexture2D<float4> gOutPositionDepth : register(u0);
RWTexture2D<float4> gOutNormal : register(u1);
RWTexture2D<float4> gOutAlbedo : register(u2);
RWTexture2D<float4> gOutDirect : register(u3);

[numthreads(8, 8, 1)]
void csGBuffer(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    CameraBasis camera = makeWorkbenchCamera();
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);
    float3 direction = cameraRayDirection(camera, uv, aspect);

    float3 hitPosition;
    float3 hitNormal;
    float3 albedo;
    if (!traceCameraRay(camera.position, direction,
                        hitPosition, hitNormal, albedo)) {
        gOutPositionDepth[id.xy] = 0.0;
        gOutNormal[id.xy] = 0.0;
        gOutAlbedo[id.xy] = 0.0;
        gOutDirect[id.xy] = float4(skyColor(direction), 0.0);
        return;
    }

    float viewDepth = dot(hitPosition - camera.position, camera.forward);
    float3 direct = evaluateDirectDiffuse(hitPosition, hitNormal, albedo);
    gOutPositionDepth[id.xy] = float4(hitPosition, viewDepth);
    gOutNormal[id.xy] = float4(hitNormal, 1.0);
    gOutAlbedo[id.xy] = float4(albedo, 1.0);
    gOutDirect[id.xy] = float4(direct, 1.0);
}
