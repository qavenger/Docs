#pragma once

#include "voxel_gi_common.hlsli"

// Irradiance probe grid shared by bake and resolve.
//
// An 8x4x8 grid of SH-L1 radiance probes fitted to the room interior. The
// grid bounds are a workbench constant (probes hug the walkable volume, not
// the full voxel bounds, so corner probes do not start inside the walls).
//
// Storage: three Texture3D<float4>, one per color channel, each texel holding
// the four L0+L1 coefficients (c0, c1x, c1y, c1z) of that probe.

static const uint3 kProbeGridSize = uint3(8, 4, 8);
static const float3 kProbeGridMin = float3(-3.45, 0.16, -3.45);
static const float3 kProbeGridExtent = float3(6.9, 2.55, 6.9);
static const uint kProbeRayCount = 64;

float3 probeWorldPosition(uint3 probeIndex) {
    float3 t = (float3(probeIndex) + 0.5) / float3(kProbeGridSize);
    return kProbeGridMin + t * kProbeGridExtent;
}

// Deterministic Fibonacci sphere: identical direction set in bake and any
// future debug pass.
float3 fibonacciSphereDirection(uint index, uint count) {
    float u = (float(index) + 0.5) / count;
    float cosTheta = 1.0 - 2.0 * u;
    float sinTheta = sqrt(saturate(1.0 - cosTheta * cosTheta));
    float phi = float(index) * 2.399963229728653; // golden angle
    return float3(sinTheta * cos(phi), cosTheta, sinTheta * sin(phi));
}

// SH-L1 basis (Y00, Y1-1=y, Y10=z, Y11=x ordering packed as c0, c1x/y/z by
// component for readability).
float4 shEvaluateL1(float3 direction) {
    return float4(0.282095,
                  0.488603 * direction.x,
                  0.488603 * direction.y,
                  0.488603 * direction.z);
}

// Irradiance reconstruction: E(n) = A0*c0*Y00 + A1*sum(c1 * Y1(n)),
// A0 = pi, A1 = 2*pi/3 (Ramamoorthi & Hanrahan).
float shIrradiance(float4 coefficients, float3 normal) {
    float4 basis = shEvaluateL1(normal);
    return max(0.0,
               3.14159265 * coefficients.x * basis.x +
               2.09439510 * (coefficients.y * basis.y +
                             coefficients.z * basis.z +
                             coefficients.w * basis.w));
}
