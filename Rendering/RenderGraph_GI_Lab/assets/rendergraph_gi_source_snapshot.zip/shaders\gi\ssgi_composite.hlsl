#include "voxel_gi_common.hlsli"

// SSGI step 3: composite direct + screen-space indirect.
//
// View modes (cameraPositionMode.w):
//   0 = final (direct + albedo * indirect * AO + ambient floor)
//   1 = ambient occlusion only
//   2 = direct only (what SSGI starts from)
//   3 = indirect only

Texture2D<float4> gAlbedo : register(t0);
Texture2D<float4> gDirect : register(t1);
Texture2D<float4> gIndirect : register(t2);
RWTexture2D<float4> gResolveTarget : register(u0);
SamplerState gLinearClamp : register(s0);

[numthreads(8, 8, 1)]
void csComposite(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float4 albedo = gAlbedo.SampleLevel(gLinearClamp, uv, 0);
    float4 direct = gDirect.SampleLevel(gLinearClamp, uv, 0);
    float4 indirect = gIndirect.SampleLevel(gLinearClamp, uv, 0);
    float debugMode = gGI.cameraPositionMode.w;

    if (albedo.a < 0.5) {
        // Sky pixel: direct already stores the sky radiance.
        float3 sky = debugMode > 0.5 && debugMode < 1.5
            ? float3(1.0, 1.0, 1.0) : direct.rgb;
        gResolveTarget[id.xy] = float4(
            debugMode > 2.5 ? float3(0.0, 0.0, 0.0) : sky, 1.0);
        return;
    }

    float3 indirectLight = albedo.rgb * indirect.rgb * indirect.a;
    float3 color;
    if (debugMode > 2.5)
        color = indirectLight * 1.9;
    else if (debugMode > 1.5)
        color = direct.rgb;
    else if (debugMode > 0.5)
        color = indirect.aaa;
    else
        color = direct.rgb + indirectLight +
                albedo.rgb * 0.015 * indirect.a;
    gResolveTarget[id.xy] = float4(color, 1.0);
}
