#pragma once

#include "voxel_gi_common.hlsli"

// Reflective Shadow Map light camera.
//
// The workbench light is an isotropic point light. Classic RSM needs a
// projective light frustum, so the RSM scheme deliberately restricts the
// point light to a wide-angle "spot" aimed at the room center and states
// that restriction instead of hiding it. Direct lighting still uses the
// full isotropic light (same evaluateDirectDiffuse as every other scheme),
// only the *indirect* VPL set is limited to this frustum.

static const float kRSMTanHalfFov = 1.45; // ~110 degree full cone
static const float kRSMMaxRayDistance = 16.0;

CameraBasis makeRSMLightCamera() {
    CameraBasis light;
    light.position = gGI.lightPositionIntensity.xyz;
    float3 target = float3(0.0, 0.45, 0.0);
    light.forward = normalize(target - light.position);
    float3 helper = abs(light.forward.y) < 0.94
        ? float3(0, 1, 0) : float3(1, 0, 0);
    light.right = normalize(cross(light.forward, helper));
    light.up = normalize(cross(light.right, light.forward));
    return light;
}

float3 rsmTexelDirection(CameraBasis light, float2 uv) {
    float2 screen = uv * 2.0 - 1.0;
    screen.y = -screen.y;
    return normalize(light.forward +
                     light.right * screen.x * kRSMTanHalfFov +
                     light.up * screen.y * kRSMTanHalfFov);
}

// World position -> RSM uv. Returns false behind the light plane.
bool projectToRSMUV(CameraBasis light, float3 worldPosition, out float2 uv) {
    float3 offset = worldPosition - light.position;
    float forwardDistance = dot(offset, light.forward);
    uv = 0.0;
    if (forwardDistance < 1e-3)
        return false;
    float2 screen;
    screen.x = dot(offset, light.right) / (forwardDistance * kRSMTanHalfFov);
    screen.y = dot(offset, light.up) / (forwardDistance * kRSMTanHalfFov);
    screen.y = -screen.y;
    uv = screen * 0.5 + 0.5;
    return true;
}

float radicalInverseBase2(uint bits) {
    bits = (bits << 16u) | (bits >> 16u);
    bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
    bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
    bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
    bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
    return float(bits) * 2.3283064365386963e-10;
}
