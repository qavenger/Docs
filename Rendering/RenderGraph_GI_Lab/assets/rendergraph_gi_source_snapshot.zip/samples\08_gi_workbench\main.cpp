// Native, cross-backend GI workbench with four switchable schemes.
//
//   --scheme=voxel  Voxelize.AnalyticScene -> VoxelMip.L1..L3
//                   -> MultiCone.Resolve -> Present            (default)
//   --scheme=rsm    RSM.Generate(light MRT) -> RSM.GatherResolve -> Present
//   --scheme=ssgi   SSGI.GBuffer -> SSGI.Trace -> SSGI.Composite -> Present
//   --scheme=probe  Probe.BakeSH -> Probe.Resolve -> Present
//
// Every scheme shares the same analytic SDF scene, the same workbench camera
// for primary visibility, the same animated isotropic point light and the
// same direct-lighting term, so their indirect answers are directly
// comparable. Each frame rebuilds all GI data from the current light state:
// history reads = 0 across all schemes, making fast light motion an explicit
// validation case. --validate runs every scheme (or just the selected one)
// through a shared 4-frame harness: final frame0, moved-light frame1,
// indirect-only view and the scheme's own debug view.

#include "../common/sample_common.h"

#include <rg/runtime/window.h>

#include <algorithm>
#include <chrono>
#include <fstream>
#include <numeric>
#include <vector>

using namespace rg;
using namespace samples;

namespace {

constexpr u32 kVoxelSize = 32;
constexpr u32 kMipCount = 4;
constexpr u32 kRSMResolution = 256;
constexpr u32 kProbeGridX = 8;
constexpr u32 kProbeGridY = 4;
constexpr u32 kProbeGridZ = 8;
constexpr u32 kRCAtlasSize = 128;
constexpr u32 kRCCascadeCount = 4;
constexpr u32 kDDGIOctSize = 8;
constexpr u32 kDDGIAtlasWidth = kProbeGridX * kProbeGridZ * kDDGIOctSize;
constexpr u32 kDDGIAtlasHeight = kProbeGridY * kDDGIOctSize;
constexpr u32 kPRTEnvCoefficients = 4;

enum class Scheme { Voxel, RSM, SSGI, Probe, RCGI, DDGI, PRT };

struct SchemeInfo {
    Scheme scheme;
    const char* name;
    const char* title;
    u32 expectedPasses;
    u32 expectedTransient;
    u32 minimumBarriers;
    const char* debugViewName; // what view mode 1 shows
    bool usesHistory;          // true = temporal by design (DDGI hysteresis)
};

constexpr SchemeInfo kSchemes[] = {
    { Scheme::Voxel, "voxel", "Voxel Cone Tracing", 6, 5, 9,
      "occupancy slice", false },
    { Scheme::RSM, "rsm", "Reflective Shadow Maps", 3, 4, 4,
      "RSM flux map", false },
    { Scheme::SSGI, "ssgi", "Screen-Space GI", 4, 6, 5,
      "ambient occlusion", false },
    { Scheme::Probe, "probe", "SH Irradiance Probes", 3, 4, 4,
      "leaky trilinear", false },
    { Scheme::RCGI, "rcgi", "Radiance Cascades (Flatland)", 9, 8, 8,
      "cast-only C0", false },
    { Scheme::DDGI, "ddgi", "DDGI Teaching-Lite", 4, 2, 6,
      "Chebyshev off (leak)", true },
    { Scheme::PRT, "prt", "PRT Transfer Probes", 4, 3, 6,
      "transfer bypassed", false },
};

const SchemeInfo& schemeInfo(Scheme scheme) {
    for (const auto& info : kSchemes)
        if (info.scheme == scheme)
            return info;
    return kSchemes[0];
}

struct GIPush {
    f32 lightPositionIntensity[4];
    f32 lightColorTime[4];
    f32 cameraPositionMode[4];
    f32 volumeMinExtent[4];
    u32 dimensions[4];
};
static_assert(sizeof(GIPush) == 80);

struct Pipelines {
    // Shared across schemes.
    std::shared_ptr<rhi::IPipeline> present;
    std::shared_ptr<rhi::ISampler> linearClamp;
    // Voxel cone tracing.
    std::shared_ptr<rhi::IPipeline> voxelize;
    std::shared_ptr<rhi::IPipeline> downsample;
    std::shared_ptr<rhi::IPipeline> coneResolve;
    // Reflective shadow maps.
    std::shared_ptr<rhi::IPipeline> rsmGenerate;
    std::shared_ptr<rhi::IPipeline> rsmResolve;
    // Screen-space GI.
    std::shared_ptr<rhi::IPipeline> ssgiGBuffer;
    std::shared_ptr<rhi::IPipeline> ssgiTrace;
    std::shared_ptr<rhi::IPipeline> ssgiComposite;
    // SH irradiance probes.
    std::shared_ptr<rhi::IPipeline> probeBake;
    std::shared_ptr<rhi::IPipeline> probeResolve;
    // Flatland radiance cascades.
    std::shared_ptr<rhi::IPipeline> rcCast;
    std::shared_ptr<rhi::IPipeline> rcMerge;
    std::shared_ptr<rhi::IPipeline> rcResolve;
    // DDGI teaching-lite.
    std::shared_ptr<rhi::IPipeline> ddgiTrace;
    std::shared_ptr<rhi::IPipeline> ddgiConvolve;
    std::shared_ptr<rhi::IPipeline> ddgiResolve;
    // PRT transfer probes.
    std::shared_ptr<rhi::IPipeline> prtBake;
    std::shared_ptr<rhi::IPipeline> prtEnvironment;
    std::shared_ptr<rhi::IPipeline> prtResolve;
};

// DDGI is the one deliberately temporal scheme: its radiance / distance
// moment atlases ping-pong across frames outside the graph and get imported
// each frame (hysteresis needs yesterday's atlas).
struct DDGIHistory {
    std::shared_ptr<rhi::ITexture> radiance[2];
    std::shared_ptr<rhi::ITexture> moments[2];
    rhi::ResourceState radianceState[2];
    rhi::ResourceState momentsState[2];
    u32 readIndex = 0;
    u32 frameIndex = 0;
};

DDGIHistory createDDGIHistory(rhi::IDevice* device) {
    DDGIHistory history;
    for (u32 slot = 0; slot < 2; ++slot) {
        history.radiance[slot] = device->createTexture({
            .name = "DDGI.Radiance." + std::to_string(slot),
            .width = kDDGIAtlasWidth,
            .height = kDDGIAtlasHeight,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
        history.moments[slot] = device->createTexture({
            .name = "DDGI.Moments." + std::to_string(slot),
            .width = kDDGIAtlasWidth,
            .height = kDDGIAtlasHeight,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
        history.radianceState[slot] = rhi::ResourceState::Common;
        history.momentsState[slot] = rhi::ResourceState::Common;
    }
    return history;
}

Pipelines createPipelines(rhi::IDevice* device, rhi::Format outputFormat,
                          shader::TargetIL targetIL, Scheme scheme) {
    shader::ShaderCompiler compiler;
    const std::filesystem::path shaderDir = RG_SHADER_DIR;
    const auto compileCompute = [&](const char* file, const char* entry) {
        auto shaderBlob = compiler.compileOrDie({
            .sourcePath = shaderDir / "gi" / file,
            .entryPoint = entry,
            .stage = rhi::ShaderStage::Compute,
            .target = targetIL,
        });
        rhi::ComputePipelineDesc desc;
        desc.name = std::string(file) + ":" + entry;
        desc.computeShader = std::move(shaderBlob);
        return device->createComputePipeline(desc);
    };

    Pipelines pipelines;
    switch (scheme) {
    case Scheme::Voxel:
        pipelines.voxelize = compileCompute(
            "voxelize_analytic.hlsl", "csVoxelize");
        pipelines.downsample = compileCompute("voxel_mip.hlsl", "csDownsample");
        pipelines.coneResolve = compileCompute(
            "voxel_cone_resolve.hlsl", "csResolve");
        break;
    case Scheme::RSM:
        pipelines.rsmGenerate = compileCompute(
            "rsm_generate.hlsl", "csGenerate");
        pipelines.rsmResolve = compileCompute("rsm_resolve.hlsl", "csResolve");
        break;
    case Scheme::SSGI:
        pipelines.ssgiGBuffer = compileCompute(
            "ssgi_gbuffer.hlsl", "csGBuffer");
        pipelines.ssgiTrace = compileCompute("ssgi_trace.hlsl", "csTrace");
        pipelines.ssgiComposite = compileCompute(
            "ssgi_composite.hlsl", "csComposite");
        break;
    case Scheme::Probe:
        pipelines.probeBake = compileCompute("probe_bake.hlsl", "csBake");
        pipelines.probeResolve = compileCompute(
            "probe_resolve.hlsl", "csResolve");
        break;
    case Scheme::RCGI:
        pipelines.rcCast = compileCompute("rc_cast.hlsl", "csCast");
        pipelines.rcMerge = compileCompute("rc_merge.hlsl", "csMerge");
        pipelines.rcResolve = compileCompute("rc_resolve.hlsl", "csResolve");
        break;
    case Scheme::DDGI:
        pipelines.ddgiTrace = compileCompute("ddgi_trace.hlsl", "csTrace");
        pipelines.ddgiConvolve = compileCompute(
            "ddgi_convolve.hlsl", "csConvolve");
        pipelines.ddgiResolve = compileCompute(
            "ddgi_resolve.hlsl", "csResolve");
        break;
    case Scheme::PRT:
        pipelines.prtBake = compileCompute("prt_bake.hlsl", "csBake");
        pipelines.prtEnvironment = compileCompute(
            "prt_env.hlsl", "csEnvironment");
        pipelines.prtResolve = compileCompute("prt_resolve.hlsl", "csResolve");
        break;
    }
    {
        auto vs = compiler.compileOrDie({
            .sourcePath = shaderDir / "gi" / "gi_present.hlsl",
            .entryPoint = "vsMain",
            .stage = rhi::ShaderStage::Vertex,
            .target = targetIL,
        });
        auto ps = compiler.compileOrDie({
            .sourcePath = shaderDir / "gi" / "gi_present.hlsl",
            .entryPoint = "psPresent",
            .stage = rhi::ShaderStage::Pixel,
            .target = targetIL,
        });
        rhi::GraphicsPipelineDesc desc;
        desc.name = "GI.Present";
        desc.vertexShader = std::move(vs);
        desc.pixelShader = std::move(ps);
        desc.rasterizer.cull = rhi::CullMode::None;
        desc.renderTargetFormats = { outputFormat };
        pipelines.present = device->createGraphicsPipeline(desc);
    }
    pipelines.linearClamp = device->createSampler({
        .filter = rhi::FilterMode::Linear,
        .addressU = rhi::AddressMode::Clamp,
        .addressV = rhi::AddressMode::Clamp,
        .addressW = rhi::AddressMode::Clamp,
    });
    return pipelines;
}

GIPush makePush(f32 time, f32 viewMode, u32 outputWidth, u32 outputHeight) {
    // Isotropic point light. Position is animated; forward is intentionally
    // absent because it has no directional cone. (The RSM scheme restricts
    // its VPL set to a wide frustum aimed at the room and documents that.)
    const f32 lightX = -2.35f + 4.55f * (0.5f + 0.5f * std::sin(time * 1.73f));
    const f32 lightZ = 1.55f + 1.15f * std::sin(time * 1.11f + 0.7f);
    GIPush push{};
    push.lightPositionIntensity[0] = lightX;
    push.lightPositionIntensity[1] = 2.45f;
    push.lightPositionIntensity[2] = lightZ;
    push.lightPositionIntensity[3] = 7.5f;
    push.lightColorTime[0] = 1.0f;
    push.lightColorTime[1] = 0.76f;
    push.lightColorTime[2] = 0.42f;
    push.lightColorTime[3] = time;
    push.cameraPositionMode[0] = 0.0f;
    push.cameraPositionMode[1] = 3.25f;
    push.cameraPositionMode[2] = 7.15f;
    push.cameraPositionMode[3] = viewMode;
    push.volumeMinExtent[0] = -4.0f;
    push.volumeMinExtent[1] = -0.45f;
    push.volumeMinExtent[2] = -4.0f;
    push.volumeMinExtent[3] = 8.0f;
    push.dimensions[0] = kVoxelSize;
    push.dimensions[1] = kVoxelSize;
    push.dimensions[2] = outputWidth;
    push.dimensions[3] = outputHeight;
    return push;
}

rdg::RGTexture createResolveTexture(rdg::RenderGraph& graph,
                                    u32 width, u32 height) {
    return graph.createTexture({
        .name = "GI.ResolvedHDR",
        .width = width,
        .height = height,
        .format = rhi::Format::RGBA16_FLOAT,
        .usage = rhi::TextureUsage::UnorderedAccess |
                 rhi::TextureUsage::ShaderResource,
    });
}

void addPresentPass(rdg::RenderGraph& graph, const Pipelines& pipelines,
                    rdg::RGTexture resolvedHDR, rdg::RGTexture finalTexture) {
    graph.addPass("GI.Present", rdg::PassFlags::Raster,
                  [&, resolvedHDR, finalTexture](rdg::PassBuilder& builder) {
        builder.readTexture(resolvedHDR);
        builder.colorTarget(0, finalTexture, rhi::LoadOp::DontCare);
        auto pipeline = pipelines.present;
        auto sampler = pipelines.linearClamp;
        return [resolvedHDR, pipeline, sampler](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(resolvedHDR));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().draw(3);
        };
    });
}

// --- Scheme builders --------------------------------------------------------

void buildVoxelGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                     rdg::RGTexture finalTexture, const GIPush& push) {
    std::array<rdg::RGTexture, kMipCount> volumes;
    for (u32 level = 0; level < kMipCount; ++level) {
        const u32 size = kVoxelSize >> level;
        volumes[level] = graph.createTexture({
            .name = "GI.Voxel.L" + std::to_string(level),
            .dimension = rhi::TextureDimension::Tex3D,
            .width = size,
            .height = size,
            .depthOrArraySize = size,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
    }
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);

    graph.addPass("GI.01 Voxelize Analytic Scene", rdg::PassFlags::Compute,
                  [&, voxelL0 = volumes[0], push](rdg::PassBuilder& builder) {
        builder.writeTexture(voxelL0);
        auto pipeline = pipelines.voxelize;
        GIPush passPush = push;
        passPush.dimensions[0] = kVoxelSize;
        passPush.dimensions[1] = kVoxelSize;
        return [voxelL0, pipeline, passPush](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(0, 0, context.texture(voxelL0));
            context.cmd().setPushConstants(&passPush, sizeof(passPush));
            context.cmd().dispatch((kVoxelSize + 3) / 4,
                                   (kVoxelSize + 3) / 4,
                                   (kVoxelSize + 3) / 4);
        };
    });

    for (u32 level = 1; level < kMipCount; ++level) {
        const auto source = volumes[level - 1];
        const auto target = volumes[level];
        const u32 sourceSize = kVoxelSize >> (level - 1);
        const u32 targetSize = kVoxelSize >> level;
        const std::string passName = "GI.0" + std::to_string(level + 1) +
                                     " Voxel Mip L" + std::to_string(level);
        graph.addPass(passName, rdg::PassFlags::Compute,
                      [&, source, target, sourceSize, targetSize,
                       push](rdg::PassBuilder& builder) {
            builder.readTexture(source);
            builder.writeTexture(target);
            auto pipeline = pipelines.downsample;
            GIPush passPush = push;
            passPush.dimensions[0] = sourceSize;
            passPush.dimensions[1] = targetSize;
            return [source, target, pipeline, passPush,
                    targetSize](rdg::PassContext& context) {
                context.cmd().setPipeline(pipeline.get());
                context.cmd().setTextureSRV(0, 0, context.texture(source));
                context.cmd().setTextureUAV(0, 0, context.texture(target));
                context.cmd().setPushConstants(&passPush, sizeof(passPush));
                context.cmd().dispatch((targetSize + 3) / 4,
                                       (targetSize + 3) / 4,
                                       (targetSize + 3) / 4);
            };
        });
    }

    graph.addPass("GI.05 Multi-Cone Resolve", rdg::PassFlags::Compute,
                  [&, resolvedHDR, volumes, push](rdg::PassBuilder& builder) {
        for (const auto volume : volumes)
            builder.readTexture(volume);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.coneResolve;
        auto sampler = pipelines.linearClamp;
        return [resolvedHDR, volumes, pipeline, sampler,
                push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            for (u32 level = 0; level < kMipCount; ++level)
                context.cmd().setTextureSRV(
                    0, level, context.texture(volumes[level]));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((push.dimensions[2] + 7) / 8,
                                   (push.dimensions[3] + 7) / 8, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

void buildRSMGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                   rdg::RGTexture finalTexture, const GIPush& push) {
    const auto makeRSMTexture = [&](const char* name) {
        return graph.createTexture({
            .name = name,
            .width = kRSMResolution,
            .height = kRSMResolution,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
    };
    auto rsmPositionDepth = makeRSMTexture("RSM.PositionDepth");
    auto rsmNormal = makeRSMTexture("RSM.Normal");
    auto rsmFlux = makeRSMTexture("RSM.Flux");
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);

    graph.addPass("RSM.01 Generate Light MRT", rdg::PassFlags::Compute,
                  [&, rsmPositionDepth, rsmNormal, rsmFlux,
                   push](rdg::PassBuilder& builder) {
        builder.writeTexture(rsmPositionDepth);
        builder.writeTexture(rsmNormal);
        builder.writeTexture(rsmFlux);
        auto pipeline = pipelines.rsmGenerate;
        GIPush passPush = push;
        passPush.dimensions[0] = kRSMResolution;
        return [rsmPositionDepth, rsmNormal, rsmFlux, pipeline,
                passPush](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(
                0, 0, context.texture(rsmPositionDepth));
            context.cmd().setTextureUAV(0, 1, context.texture(rsmNormal));
            context.cmd().setTextureUAV(0, 2, context.texture(rsmFlux));
            context.cmd().setPushConstants(&passPush, sizeof(passPush));
            context.cmd().dispatch((kRSMResolution + 7) / 8,
                                   (kRSMResolution + 7) / 8, 1);
        };
    });

    graph.addPass("RSM.02 VPL Gather Resolve", rdg::PassFlags::Compute,
                  [&, rsmPositionDepth, rsmNormal, rsmFlux, resolvedHDR,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(rsmPositionDepth);
        builder.readTexture(rsmNormal);
        builder.readTexture(rsmFlux);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.rsmResolve;
        auto sampler = pipelines.linearClamp;
        GIPush passPush = push;
        passPush.dimensions[0] = kRSMResolution;
        return [rsmPositionDepth, rsmNormal, rsmFlux, resolvedHDR, pipeline,
                sampler, passPush](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(
                0, 0, context.texture(rsmPositionDepth));
            context.cmd().setTextureSRV(0, 1, context.texture(rsmNormal));
            context.cmd().setTextureSRV(0, 2, context.texture(rsmFlux));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().setPushConstants(&passPush, sizeof(passPush));
            context.cmd().dispatch((passPush.dimensions[2] + 7) / 8,
                                   (passPush.dimensions[3] + 7) / 8, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

void buildSSGIGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                    rdg::RGTexture finalTexture, const GIPush& push) {
    const auto makeScreenTexture = [&](const char* name) {
        return graph.createTexture({
            .name = name,
            .width = push.dimensions[2],
            .height = push.dimensions[3],
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
    };
    auto positionDepth = makeScreenTexture("SSGI.PositionDepth");
    auto normal = makeScreenTexture("SSGI.Normal");
    auto albedo = makeScreenTexture("SSGI.Albedo");
    auto direct = makeScreenTexture("SSGI.Direct");
    auto indirect = makeScreenTexture("SSGI.IndirectAO");
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);
    const u32 groupsX = (push.dimensions[2] + 7) / 8;
    const u32 groupsY = (push.dimensions[3] + 7) / 8;

    graph.addPass("SSGI.01 Camera GBuffer", rdg::PassFlags::Compute,
                  [&, positionDepth, normal, albedo, direct,
                   push](rdg::PassBuilder& builder) {
        builder.writeTexture(positionDepth);
        builder.writeTexture(normal);
        builder.writeTexture(albedo);
        builder.writeTexture(direct);
        auto pipeline = pipelines.ssgiGBuffer;
        return [positionDepth, normal, albedo, direct, pipeline, push,
                groupsX, groupsY](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(0, 0, context.texture(positionDepth));
            context.cmd().setTextureUAV(0, 1, context.texture(normal));
            context.cmd().setTextureUAV(0, 2, context.texture(albedo));
            context.cmd().setTextureUAV(0, 3, context.texture(direct));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch(groupsX, groupsY, 1);
        };
    });

    graph.addPass("SSGI.02 Screen-Space Trace", rdg::PassFlags::Compute,
                  [&, positionDepth, normal, direct, indirect,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(positionDepth);
        builder.readTexture(normal);
        builder.readTexture(direct);
        builder.writeTexture(indirect);
        auto pipeline = pipelines.ssgiTrace;
        auto sampler = pipelines.linearClamp;
        return [positionDepth, normal, direct, indirect, pipeline, sampler,
                push, groupsX, groupsY](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(positionDepth));
            context.cmd().setTextureSRV(0, 1, context.texture(normal));
            context.cmd().setTextureSRV(0, 2, context.texture(direct));
            context.cmd().setTextureUAV(0, 0, context.texture(indirect));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch(groupsX, groupsY, 1);
        };
    });

    graph.addPass("SSGI.03 Composite", rdg::PassFlags::Compute,
                  [&, albedo, direct, indirect, resolvedHDR,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(albedo);
        builder.readTexture(direct);
        builder.readTexture(indirect);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.ssgiComposite;
        auto sampler = pipelines.linearClamp;
        return [albedo, direct, indirect, resolvedHDR, pipeline, sampler,
                push, groupsX, groupsY](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(albedo));
            context.cmd().setTextureSRV(0, 1, context.texture(direct));
            context.cmd().setTextureSRV(0, 2, context.texture(indirect));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch(groupsX, groupsY, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

void buildProbeGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                     rdg::RGTexture finalTexture, const GIPush& push) {
    const auto makeProbeTexture = [&](const char* name) {
        return graph.createTexture({
            .name = name,
            .dimension = rhi::TextureDimension::Tex3D,
            .width = kProbeGridX,
            .height = kProbeGridY,
            .depthOrArraySize = kProbeGridZ,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
    };
    auto shRed = makeProbeTexture("Probe.SH.R");
    auto shGreen = makeProbeTexture("Probe.SH.G");
    auto shBlue = makeProbeTexture("Probe.SH.B");
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);

    graph.addPass("Probe.01 Bake SH-L1 Grid", rdg::PassFlags::Compute,
                  [&, shRed, shGreen, shBlue, push](rdg::PassBuilder& builder) {
        builder.writeTexture(shRed);
        builder.writeTexture(shGreen);
        builder.writeTexture(shBlue);
        auto pipeline = pipelines.probeBake;
        return [shRed, shGreen, shBlue, pipeline,
                push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(0, 0, context.texture(shRed));
            context.cmd().setTextureUAV(0, 1, context.texture(shGreen));
            context.cmd().setTextureUAV(0, 2, context.texture(shBlue));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((kProbeGridX + 3) / 4,
                                   (kProbeGridY + 3) / 4,
                                   (kProbeGridZ + 3) / 4);
        };
    });

    graph.addPass("Probe.02 Visibility-Weighted Resolve",
                  rdg::PassFlags::Compute,
                  [&, shRed, shGreen, shBlue, resolvedHDR,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(shRed);
        builder.readTexture(shGreen);
        builder.readTexture(shBlue);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.probeResolve;
        return [shRed, shGreen, shBlue, resolvedHDR, pipeline,
                push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(shRed));
            context.cmd().setTextureSRV(0, 1, context.texture(shGreen));
            context.cmd().setTextureSRV(0, 2, context.texture(shBlue));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((push.dimensions[2] + 7) / 8,
                                   (push.dimensions[3] + 7) / 8, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

void buildRCGIGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                    rdg::RGTexture finalTexture, const GIPush& push) {
    // All cascade atlases share one size - the classic RC invariant:
    // halving probe resolution exactly pays for quadrupling directions.
    const auto makeAtlas = [&](const std::string& name) {
        return graph.createTexture({
            .name = name,
            .width = kRCAtlasSize,
            .height = kRCAtlasSize,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
    };
    std::array<rdg::RGTexture, kRCCascadeCount> cast;
    for (u32 cascade = 0; cascade < kRCCascadeCount; ++cascade)
        cast[cascade] = makeAtlas("RC.Cast.C" + std::to_string(cascade));
    // merged[kRCCascadeCount - 1] is cast[kRCCascadeCount - 1] itself.
    std::array<rdg::RGTexture, kRCCascadeCount> merged;
    merged[kRCCascadeCount - 1] = cast[kRCCascadeCount - 1];
    for (u32 cascade = 0; cascade + 1 < kRCCascadeCount; ++cascade)
        merged[cascade] = makeAtlas("RC.Merged.C" + std::to_string(cascade));
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);
    const u32 atlasGroups = (kRCAtlasSize + 7) / 8;

    for (u32 cascade = 0; cascade < kRCCascadeCount; ++cascade) {
        const auto target = cast[cascade];
        const std::string passName =
            "RC.0" + std::to_string(cascade + 1) + " Cast Intervals C" +
            std::to_string(cascade);
        graph.addPass(passName, rdg::PassFlags::Compute,
                      [&, target, cascade, push](rdg::PassBuilder& builder) {
            builder.writeTexture(target);
            auto pipeline = pipelines.rcCast;
            GIPush passPush = push;
            passPush.dimensions[0] = cascade;
            return [target, pipeline, passPush,
                    atlasGroups](rdg::PassContext& context) {
                context.cmd().setPipeline(pipeline.get());
                context.cmd().setTextureUAV(0, 0, context.texture(target));
                context.cmd().setPushConstants(&passPush, sizeof(passPush));
                context.cmd().dispatch(atlasGroups, atlasGroups, 1);
            };
        });
    }

    for (i32 cascade = i32(kRCCascadeCount) - 2; cascade >= 0; --cascade) {
        const auto castCurrent = cast[cascade];
        const auto mergedCoarser = merged[cascade + 1];
        const auto target = merged[cascade];
        const std::string passName =
            "RC.0" + std::to_string(kRCCascadeCount + 3 - cascade) +
            " Merge C" + std::to_string(cascade + 1) + " into C" +
            std::to_string(cascade);
        graph.addPass(passName, rdg::PassFlags::Compute,
                      [&, castCurrent, mergedCoarser, target, cascade,
                       push](rdg::PassBuilder& builder) {
            builder.readTexture(castCurrent);
            builder.readTexture(mergedCoarser);
            builder.writeTexture(target);
            auto pipeline = pipelines.rcMerge;
            GIPush passPush = push;
            passPush.dimensions[0] = u32(cascade);
            return [castCurrent, mergedCoarser, target, pipeline, passPush,
                    atlasGroups](rdg::PassContext& context) {
                context.cmd().setPipeline(pipeline.get());
                context.cmd().setTextureSRV(0, 0, context.texture(castCurrent));
                context.cmd().setTextureSRV(
                    0, 1, context.texture(mergedCoarser));
                context.cmd().setTextureUAV(0, 0, context.texture(target));
                context.cmd().setPushConstants(&passPush, sizeof(passPush));
                context.cmd().dispatch(atlasGroups, atlasGroups, 1);
            };
        });
    }

    graph.addPass("RC.08 Fluence Resolve", rdg::PassFlags::Compute,
                  [&, merged0 = merged[0], cast0 = cast[0], resolvedHDR,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(merged0);
        builder.readTexture(cast0);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.rcResolve;
        return [merged0, cast0, resolvedHDR, pipeline,
                push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(merged0));
            context.cmd().setTextureSRV(0, 1, context.texture(cast0));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((push.dimensions[2] + 7) / 8,
                                   (push.dimensions[3] + 7) / 8, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

void buildDDGIGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                    rdg::RGTexture finalTexture, const GIPush& push,
                    DDGIHistory& history) {
    const u32 read = history.readIndex;
    const u32 write = 1 - read;
    auto prevRadiance = graph.importTexture(
        history.radiance[read].get(), history.radianceState[read],
        rhi::ResourceState::ShaderResource);
    auto prevMoments = graph.importTexture(
        history.moments[read].get(), history.momentsState[read],
        rhi::ResourceState::ShaderResource);
    auto currRadiance = graph.importTexture(
        history.radiance[write].get(), history.radianceState[write],
        rhi::ResourceState::ShaderResource);
    auto currMoments = graph.importTexture(
        history.moments[write].get(), history.momentsState[write],
        rhi::ResourceState::ShaderResource);
    history.radianceState[read] = rhi::ResourceState::ShaderResource;
    history.momentsState[read] = rhi::ResourceState::ShaderResource;
    history.radianceState[write] = rhi::ResourceState::ShaderResource;
    history.momentsState[write] = rhi::ResourceState::ShaderResource;

    auto irradianceAtlas = graph.createTexture({
        .name = "DDGI.Irradiance",
        .width = kDDGIAtlasWidth,
        .height = kDDGIAtlasHeight,
        .format = rhi::Format::RGBA16_FLOAT,
        .usage = rhi::TextureUsage::UnorderedAccess |
                 rhi::TextureUsage::ShaderResource,
    });
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);
    const u32 atlasGroupsX = (kDDGIAtlasWidth + 7) / 8;
    const u32 atlasGroupsY = (kDDGIAtlasHeight + 7) / 8;

    graph.addPass("DDGI.01 Trace & Hysteresis Blend", rdg::PassFlags::Compute,
                  [&, prevRadiance, prevMoments, currRadiance, currMoments,
                   push, frame = history.frameIndex](
                      rdg::PassBuilder& builder) {
        builder.readTexture(prevRadiance);
        builder.readTexture(prevMoments);
        builder.writeTexture(currRadiance);
        builder.writeTexture(currMoments);
        auto pipeline = pipelines.ddgiTrace;
        GIPush passPush = push;
        passPush.dimensions[0] = frame;
        return [prevRadiance, prevMoments, currRadiance, currMoments,
                pipeline, passPush, atlasGroupsX,
                atlasGroupsY](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(prevRadiance));
            context.cmd().setTextureSRV(0, 1, context.texture(prevMoments));
            context.cmd().setTextureUAV(0, 0, context.texture(currRadiance));
            context.cmd().setTextureUAV(0, 1, context.texture(currMoments));
            context.cmd().setPushConstants(&passPush, sizeof(passPush));
            context.cmd().dispatch(atlasGroupsX, atlasGroupsY, 1);
        };
    });

    graph.addPass("DDGI.02 Cosine Convolve Irradiance",
                  rdg::PassFlags::Compute,
                  [&, currRadiance, irradianceAtlas,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(currRadiance);
        builder.writeTexture(irradianceAtlas);
        auto pipeline = pipelines.ddgiConvolve;
        return [currRadiance, irradianceAtlas, pipeline, push, atlasGroupsX,
                atlasGroupsY](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(currRadiance));
            context.cmd().setTextureUAV(
                0, 0, context.texture(irradianceAtlas));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch(atlasGroupsX, atlasGroupsY, 1);
        };
    });

    graph.addPass("DDGI.03 Chebyshev Resolve", rdg::PassFlags::Compute,
                  [&, irradianceAtlas, currMoments, currRadiance, resolvedHDR,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(irradianceAtlas);
        builder.readTexture(currMoments);
        builder.readTexture(currRadiance);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.ddgiResolve;
        return [irradianceAtlas, currMoments, currRadiance, resolvedHDR,
                pipeline, push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(
                0, 0, context.texture(irradianceAtlas));
            context.cmd().setTextureSRV(0, 1, context.texture(currMoments));
            context.cmd().setTextureSRV(0, 2, context.texture(currRadiance));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((push.dimensions[2] + 7) / 8,
                                   (push.dimensions[3] + 7) / 8, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

void buildPRTGraph(rdg::RenderGraph& graph, const Pipelines& pipelines,
                   rdg::RGTexture finalTexture, const GIPush& push) {
    auto transfer = graph.createTexture({
        .name = "PRT.Transfer",
        .dimension = rhi::TextureDimension::Tex3D,
        .width = kProbeGridX,
        .height = kProbeGridY,
        .depthOrArraySize = kProbeGridZ,
        .format = rhi::Format::RGBA16_FLOAT,
        .usage = rhi::TextureUsage::UnorderedAccess |
                 rhi::TextureUsage::ShaderResource,
    });
    auto environmentSH = graph.createTexture({
        .name = "PRT.EnvironmentSH",
        .width = kPRTEnvCoefficients,
        .height = 1,
        .format = rhi::Format::RGBA16_FLOAT,
        .usage = rhi::TextureUsage::UnorderedAccess |
                 rhi::TextureUsage::ShaderResource,
    });
    auto resolvedHDR = createResolveTexture(
        graph, push.dimensions[2], push.dimensions[3]);

    graph.addPass("PRT.01 Bake Transfer Probes", rdg::PassFlags::Compute,
                  [&, transfer, push](rdg::PassBuilder& builder) {
        builder.writeTexture(transfer);
        auto pipeline = pipelines.prtBake;
        return [transfer, pipeline, push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(0, 0, context.texture(transfer));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((kProbeGridX + 3) / 4,
                                   (kProbeGridY + 3) / 4,
                                   (kProbeGridZ + 3) / 4);
        };
    });

    graph.addPass("PRT.02 Environment SH", rdg::PassFlags::Compute,
                  [&, environmentSH, push](rdg::PassBuilder& builder) {
        builder.writeTexture(environmentSH);
        auto pipeline = pipelines.prtEnvironment;
        return [environmentSH, pipeline, push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(0, 0, context.texture(environmentSH));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch(1, 1, 1);
        };
    });

    graph.addPass("PRT.03 Relight Resolve", rdg::PassFlags::Compute,
                  [&, transfer, environmentSH, resolvedHDR,
                   push](rdg::PassBuilder& builder) {
        builder.readTexture(transfer);
        builder.readTexture(environmentSH);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.prtResolve;
        return [transfer, environmentSH, resolvedHDR, pipeline,
                push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(transfer));
            context.cmd().setTextureSRV(0, 1, context.texture(environmentSH));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((push.dimensions[2] + 7) / 8,
                                   (push.dimensions[3] + 7) / 8, 1);
        };
    });

    addPresentPass(graph, pipelines, resolvedHDR, finalTexture);
}

rdg::RenderGraph::Stats buildAndExecute(
        rhi::IDevice* device, rdg::TransientPool& transientPool,
        rhi::ICommandList* commandList, const Pipelines& pipelines,
        Scheme scheme, rhi::ITexture* finalTarget,
        rhi::ResourceState targetCurrentState,
        rhi::ResourceState targetFinalState, f32 time, f32 viewMode,
        DDGIHistory* history) {
    rdg::RenderGraph graph(device, &transientPool);
    const auto& outputDesc = finalTarget->desc();
    auto push = makePush(time, viewMode, outputDesc.width, outputDesc.height);
    auto finalTexture = graph.importTexture(
        finalTarget, targetCurrentState, targetFinalState);

    switch (scheme) {
    case Scheme::Voxel:
        buildVoxelGraph(graph, pipelines, finalTexture, push);
        break;
    case Scheme::RSM:
        buildRSMGraph(graph, pipelines, finalTexture, push);
        break;
    case Scheme::SSGI:
        buildSSGIGraph(graph, pipelines, finalTexture, push);
        break;
    case Scheme::Probe:
        buildProbeGraph(graph, pipelines, finalTexture, push);
        break;
    case Scheme::RCGI:
        buildRCGIGraph(graph, pipelines, finalTexture, push);
        break;
    case Scheme::DDGI:
        RG_CHECK(history != nullptr, "DDGI needs history atlases");
        buildDDGIGraph(graph, pipelines, finalTexture, push, *history);
        break;
    case Scheme::PRT:
        buildPRTGraph(graph, pipelines, finalTexture, push);
        break;
    }

    graph.setOutput(finalTexture);
    return graph.execute(commandList);
}

// --- Validation --------------------------------------------------------------

struct FrameMetrics {
    f64 meanLuma = 0;
    u64 hash = 1469598103934665603ull;
    u32 nonBlackPixels = 0;
};

FrameMetrics measureRGBA8(const u8* pixels, u32 width, u32 height,
                          u32 rowPitch) {
    FrameMetrics metrics;
    f64 lumaSum = 0;
    for (u32 y = 0; y < height; ++y) {
        const u8* row = pixels + u64(y) * rowPitch;
        for (u32 x = 0; x < width; ++x) {
            const u8* pixel = row + x * 4;
            const f64 luma = pixel[0] * 0.2126 +
                             pixel[1] * 0.7152 +
                             pixel[2] * 0.0722;
            lumaSum += luma;
            if (pixel[0] + pixel[1] + pixel[2] > 12)
                ++metrics.nonBlackPixels;
            for (u32 channel = 0; channel < 4; ++channel) {
                metrics.hash ^= pixel[channel];
                metrics.hash *= 1099511628211ull;
            }
        }
    }
    metrics.meanLuma = lumaSum / (width * height);
    return metrics;
}

void writeBmpRGBA8(const std::filesystem::path& path,
                   const u8* pixels, u32 width, u32 height, u32 rowPitch) {
    const u32 pixelBytes = width * height * 4;
    const u32 fileBytes = 54 + pixelBytes;
    std::array<u8, 54> header{};
    header[0] = 'B';
    header[1] = 'M';
    auto writeU32 = [&](u32 offset, u32 value) {
        for (u32 byte = 0; byte < 4; ++byte)
            header[offset + byte] = u8(value >> (byte * 8));
    };
    writeU32(2, fileBytes);
    writeU32(10, 54);
    writeU32(14, 40);
    writeU32(18, width);
    writeU32(22, height);
    header[26] = 1;
    header[28] = 32;
    writeU32(34, pixelBytes);

    std::ofstream stream(path, std::ios::binary);
    const std::string createError =
        "cannot create capture " + path.string();
    RG_CHECK(stream.good(), createError.c_str());
    stream.write(reinterpret_cast<const char*>(header.data()), header.size());
    std::vector<u8> bgra(width * 4);
    for (u32 outputY = 0; outputY < height; ++outputY) {
        const u32 sourceY = height - 1 - outputY;
        const u8* source = pixels + u64(sourceY) * rowPitch;
        for (u32 x = 0; x < width; ++x) {
            bgra[x * 4 + 0] = source[x * 4 + 2];
            bgra[x * 4 + 1] = source[x * 4 + 1];
            bgra[x * 4 + 2] = source[x * 4 + 0];
            bgra[x * 4 + 3] = 255;
        }
        stream.write(reinterpret_cast<const char*>(bgra.data()), bgra.size());
    }
    const std::string writeError =
        "failed to write capture " + path.string();
    RG_CHECK(stream.good(), writeError.c_str());
    RG_LOG_INFO("wrote native GPU preview: {}", path.string());
}

std::filesystem::path captureFileName(const std::filesystem::path& base,
                                      const char* schemeName,
                                      const char* suffix) {
    auto path = base;
    path.replace_filename(base.stem().string() + "_" + schemeName + suffix +
                          base.extension().string());
    return path;
}

int validateScheme(rhi::IDevice* device, shader::TargetIL targetIL,
                   const SchemeInfo& info,
                   const std::filesystem::path& capturePath) {
    constexpr u32 width = 320;
    constexpr u32 height = 180;
    const u32 rowPitch = (width * 4 + 255) & ~255u;
    auto pipelines = createPipelines(
        device, rhi::Format::RGBA8_UNORM, targetIL, info.scheme);
    rdg::TransientPool transientPool(device);
    auto readback = device->createBuffer({
        .name = "GI.Validation.Readback",
        .size = u64(rowPitch) * height,
        .memory = rhi::MemoryType::Readback,
    });

    // Shared 4-frame harness: final frame0, moved-light frame1,
    // indirect-only, scheme debug view (mode 1).
    constexpr u32 frameCount = 4;
    const f32 times[frameCount] = { 0.0f, 1.83f, 0.0f, 0.0f };
    const f32 viewModes[frameCount] = { 0.0f, 0.0f, 3.0f, 1.0f };
    const char* frameLabels[frameCount] = {
        "final-frame0", "final-frame1", "indirect-only", "debug-view"
    };
    FrameMetrics metrics[frameCount];
    rdg::RenderGraph::Stats stats{};
    DDGIHistory history;
    DDGIHistory* historyPointer = nullptr;
    if (info.usesHistory) {
        history = createDDGIHistory(device);
        historyPointer = &history;
    }
    for (u32 frame = 0; frame < frameCount; ++frame) {
        auto target = device->createTexture({
            .name = "GI.Validation.Target",
            .width = width,
            .height = height,
            .format = rhi::Format::RGBA8_UNORM,
            .usage = rhi::TextureUsage::RenderTarget |
                     rhi::TextureUsage::CopySrc,
        });
        auto* commandList = device->beginFrame();
        stats = buildAndExecute(
            device, transientPool, commandList, pipelines, info.scheme,
            target.get(), rhi::ResourceState::Common,
            rhi::ResourceState::CopySrc, times[frame], viewModes[frame],
            historyPointer);
        commandList->copyTextureToBuffer(
            readback.get(), 0, target.get(), 0);
        device->endFrame(nullptr);
        device->waitIdle();
        transientPool.tick();
        if (historyPointer) {
            history.readIndex = 1 - history.readIndex;
            ++history.frameIndex;
        }

        const auto* pixels = static_cast<const u8*>(readback->map());
        metrics[frame] = measureRGBA8(pixels, width, height, rowPitch);
        if (!capturePath.empty()) {
            if (frame == 0)
                writeBmpRGBA8(captureFileName(capturePath, info.name, ""),
                              pixels, width, height, rowPitch);
            else if (frame == 2)
                writeBmpRGBA8(
                    captureFileName(capturePath, info.name, "_indirect"),
                    pixels, width, height, rowPitch);
        }
        readback->unmap();
        RG_LOG_INFO(
            "[{}][{}] lightTime={:.2f} meanLuma={:.3f} nonBlack={}/{} hash={}",
            info.name, frameLabels[frame], times[frame],
            metrics[frame].meanLuma, metrics[frame].nonBlackPixels,
            width * height, metrics[frame].hash);
    }

    const bool graphOk =
        stats.totalPasses == info.expectedPasses &&
        stats.culledPasses == 0 &&
        stats.transientTextures == info.expectedTransient &&
        stats.barriers >= info.minimumBarriers;
    const bool imageOk =
        metrics[0].meanLuma > 4.0 &&
        metrics[0].nonBlackPixels > width * height * 8 / 10;
    const bool motionOk =
        metrics[0].hash != metrics[1].hash &&
        std::abs(metrics[0].meanLuma - metrics[1].meanLuma) > 0.02;
    const bool indirectOk =
        metrics[2].meanLuma > 0.10 &&
        metrics[2].nonBlackPixels > width * height / 20 &&
        metrics[2].hash != metrics[0].hash;
    // The debug view must actually show something else than the final image
    // (occupancy slice / flux map / AO / leaky-trilinear comparison).
    const bool debugViewOk =
        metrics[3].hash != metrics[0].hash &&
        metrics[3].nonBlackPixels > width * height / 40;

    RG_LOG_INFO(
        "[{}] stats: passes={} culled={} transientTex={} barriers={}",
        info.name, stats.totalPasses, stats.culledPasses,
        stats.transientTextures, stats.barriers);
    RG_LOG_INFO(
        "[{}] checks: graph={} image={} movingLight={} indirectOnly={} "
        "debugView({})={} history={}",
        info.name, graphOk, imageOk, motionOk, indirectOk,
        info.debugViewName, debugViewOk,
        info.usesHistory ? "hysteresis-by-design" : "reads=0");
    if (graphOk && imageOk && motionOk && indirectOk && debugViewOk) {
        RG_LOG_INFO("[{}] scheme validation passed ({})",
                    info.name, info.title);
        return 0;
    }
    RG_LOG_ERROR("[{}] scheme validation FAILED", info.name);
    return 1;
}

int runValidation(rhi::IDevice* device, shader::TargetIL targetIL,
                  const Scheme* singleScheme,
                  const std::filesystem::path& capturePath) {
    u32 failures = 0;
    u32 executed = 0;
    for (const auto& info : kSchemes) {
        if (singleScheme && info.scheme != *singleScheme)
            continue;
        ++executed;
        failures += validateScheme(device, targetIL, info, capturePath) ? 1 : 0;
    }
    if (failures == 0) {
        RG_LOG_INFO(
            "VALIDATION PASSED (native GI workbench, {} scheme(s), "
            "current-frame rebuild)", executed);
        return 0;
    }
    RG_LOG_ERROR("VALIDATION FAILED ({}/{} schemes failed)",
                 failures, executed);
    return 1;
}

// --- CLI ----------------------------------------------------------------------

const Scheme* parseScheme(int argc, char** argv) {
    static Scheme parsed;
    constexpr std::string_view prefix = "--scheme=";
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument = argv[index];
        if (!argument.starts_with(prefix))
            continue;
        const auto value = argument.substr(prefix.size());
        for (const auto& info : kSchemes) {
            if (value == info.name) {
                parsed = info.scheme;
                return &parsed;
            }
        }
        RG_LOG_ERROR(
            "unknown scheme '{}' (voxel|rsm|ssgi|probe|rcgi|ddgi|prt)",
            std::string(value));
    }
    return nullptr;
}

f32 parseViewMode(int argc, char** argv) {
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument = argv[index];
        if (argument == "--view=debug1") return 1.0f;
        if (argument == "--view=debug2") return 2.0f;
        if (argument == "--view=indirect") return 3.0f;
        // Voxel-era aliases kept working:
        if (argument == "--view=occupancy") return 1.0f;
        if (argument == "--view=radiance") return 2.0f;
    }
    return 0.0f;
}

std::filesystem::path parseCapturePath(int argc, char** argv) {
    constexpr std::string_view prefix = "--capture-bmp=";
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument = argv[index];
        if (argument.starts_with(prefix))
            return std::filesystem::path(argument.substr(prefix.size()));
    }
    return {};
}

const char* viewName(f32 viewMode) {
    if (viewMode > 2.5f) return "Indirect Only";
    if (viewMode > 1.5f) return "Debug View 2";
    if (viewMode > 0.5f) return "Debug View 1";
    return "Final GI";
}

} // namespace

int main(int argc, char** argv) {
    SampleApp app = SampleApp::create(argc, argv);
    auto device = std::move(app.device);
    const Scheme* schemeArgument = parseScheme(argc, argv);
    if (app.validate)
        return runValidation(device.get(), app.targetIL, schemeArgument,
                             parseCapturePath(argc, argv));

    const Scheme scheme = schemeArgument ? *schemeArgument : Scheme::Voxel;
    const auto& info = schemeInfo(scheme);
    const f32 viewMode = parseViewMode(argc, argv);
    const std::string title =
        std::string("RenderGraph 08 - Native GI Workbench [") + info.title +
        "] [" + viewName(viewMode) + "] [" +
        (app.useVulkan ? "Vulkan" : "D3D12") + "]";
    runtime::Window window({
        .title = title,
        .width = 1280,
        .height = 720,
    });
    auto swapChain = device->createSwapChain({
        .windowHandle = window.nativeHandle(),
        .width = window.width(),
        .height = window.height(),
        .format = rhi::Format::BGRA8_UNORM,
    });
    auto pipelines = createPipelines(
        device.get(), rhi::Format::BGRA8_UNORM, app.targetIL, scheme);
    rdg::TransientPool transientPool(device.get());
    DDGIHistory history;
    DDGIHistory* historyPointer = nullptr;
    if (info.usesHistory) {
        history = createDDGIHistory(device.get());
        historyPointer = &history;
    }
    const auto start = std::chrono::steady_clock::now();
    u64 frameCount = 0;

    RG_LOG_INFO(
        "scheme={} view={} | pointLight position animates in world space | "
        "forward=N/A (isotropic) | history={}",
        info.name, viewName(viewMode),
        info.usesHistory ? "hysteresis-by-design" : "reads=0");
    while (window.pumpMessages()) {
        if (window.wasResized()) {
            device->waitIdle();
            swapChain->resize(window.width(), window.height());
        }
        if (window.width() == 0 || window.height() == 0)
            continue;

        const f32 time = std::chrono::duration<f32>(
            std::chrono::steady_clock::now() - start).count();
        auto* commandList = device->beginFrame();
        const auto stats = buildAndExecute(
            device.get(), transientPool, commandList, pipelines, scheme,
            swapChain->currentBackBuffer(),
            rhi::ResourceState::Present,
            rhi::ResourceState::Present,
            time, viewMode, historyPointer);
        device->endFrame(swapChain.get());
        transientPool.tick();
        if (historyPointer) {
            history.readIndex = 1 - history.readIndex;
            ++history.frameIndex;
        }
        if (frameCount == 0) {
            RG_LOG_INFO(
                "frame0: passes={} culled={} transientTex={} barriers={}",
                stats.totalPasses, stats.culledPasses,
                stats.transientTextures, stats.barriers);
        }
        ++frameCount;
    }
    device->waitIdle();
    RG_LOG_INFO("exited after {} frames", frameCount);
    return 0;
}
