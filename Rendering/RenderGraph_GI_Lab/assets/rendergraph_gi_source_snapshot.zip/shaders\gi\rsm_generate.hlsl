#include "rsm_common.hlsli"

// RSM generation. One thread per RSM texel: march the analytic SDF from the
// light through the texel direction and record the first hit as a virtual
// point light candidate.
//
// This is the light-view MRT step of classic RSM (depth / world position /
// normal / flux), built by GPU SDF marching instead of rasterization because
// the workbench scene is analytic. dimensions.x = RSM resolution.
//
// Flux definition: each texel subtends roughly the same solid angle of the
// light frustum, so we store  flux = albedo * lightColor * intensity  and
// fold the per-texel solid angle into one shared normalization constant at
// gather time (kRSMFluxScale in rsm_resolve.hlsl).

RWTexture2D<float4> gRSMPositionDepth : register(u0); // xyz world, w hit dist
RWTexture2D<float4> gRSMNormal : register(u1);        // xyz normal, w valid
RWTexture2D<float4> gRSMFlux : register(u2);          // rgb flux

[numthreads(8, 8, 1)]
void csGenerate(uint3 id : SV_DispatchThreadID) {
    uint resolution = gGI.dimensions.x;
    if (any(id.xy >= resolution))
        return;

    CameraBasis light = makeRSMLightCamera();
    float2 uv = (float2(id.xy) + 0.5) / resolution;
    float3 direction = rsmTexelDirection(light, uv);

    float distance = 0.03;
    [loop]
    for (uint step = 0; step < 88 && distance < kRSMMaxRayDistance; ++step) {
        float3 position = light.position + direction * distance;
        SceneSample scene = sampleAnalyticScene(position);
        if (scene.distance < 0.007) {
            float3 normal = sceneNormal(position);
            // Push the VPL just off the surface along its normal so gather
            // rays never start inside geometry.
            float3 vplPosition = position + normal * 0.02;
            float3 flux = scene.albedo * gGI.lightColorTime.rgb *
                          gGI.lightPositionIntensity.w;
            gRSMPositionDepth[id.xy] = float4(vplPosition, distance);
            gRSMNormal[id.xy] = float4(normal, 1.0);
            gRSMFlux[id.xy] = float4(flux, 1.0);
            return;
        }
        distance += clamp(scene.distance * 0.78, 0.007, 0.30);
    }
    gRSMPositionDepth[id.xy] = 0.0;
    gRSMNormal[id.xy] = 0.0;
    gRSMFlux[id.xy] = 0.0;
}
