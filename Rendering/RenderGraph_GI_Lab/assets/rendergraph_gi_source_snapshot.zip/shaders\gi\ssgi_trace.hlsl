#include "voxel_gi_common.hlsli"

// SSGI step 2: screen-space hemisphere march.
//
// For every shaded pixel we march a few hemisphere rays in world space,
// reproject each sample into the GBuffer and use the stored view depth as
// the only occlusion oracle - deliberately NOT the SDF. Whatever the camera
// cannot see does not exist for this pass; that is the entire point of the
// screen-space family and its documented failure modes (offscreen energy
// loss, thickness heuristics, view dependence).
//
// Output: rgb = gathered indirect irradiance estimate, a = ambient occlusion.

Texture2D<float4> gPositionDepth : register(t0);
Texture2D<float4> gNormal : register(t1);
Texture2D<float4> gDirect : register(t2);
RWTexture2D<float4> gOutIndirect : register(u0);
SamplerState gLinearClamp : register(s0);

static const uint kRayCount = 6;
static const uint kStepCount = 12;
static const float kFirstStep = 0.09;
static const float kStepGrowth = 1.32;
static const float kThickness = 0.55;
static const float kDepthBias = 0.02;

float hash12(float2 p) {
    float3 p3 = frac(float3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return frac((p3.x + p3.y) * p3.z);
}

[numthreads(8, 8, 1)]
void csTrace(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 pixelUV = (float2(id.xy) + 0.5) / outputSize;
    float4 positionDepth = gPositionDepth.SampleLevel(gLinearClamp, pixelUV, 0);
    float4 normalFlag = gNormal.SampleLevel(gLinearClamp, pixelUV, 0);
    if (normalFlag.w < 0.5) {
        gOutIndirect[id.xy] = float4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    float3 origin = positionDepth.xyz + normalFlag.xyz * 0.03;
    float3 normal = normalFlag.xyz;
    CameraBasis camera = makeWorkbenchCamera();
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);

    float3 helper = abs(normal.y) < 0.96 ? float3(0, 1, 0) : float3(1, 0, 0);
    float3 tangent = normalize(cross(helper, normal));
    float3 bitangent = normalize(cross(normal, tangent));
    float rotation = hash12(float2(id.xy)) * 2.0 * kPi;

    float3 gathered = 0.0;
    float occlusion = 0.0;
    [loop]
    for (uint ray = 0; ray < kRayCount; ++ray) {
        // Cosine-ish lobe: fixed elevation ring rotated per pixel.
        float angle = rotation + (float(ray) + 0.5) * 2.0 * kPi / kRayCount;
        float elevation = 0.42 + 0.34 * frac(0.618034 * float(ray));
        float sinElevation = sqrt(saturate(1.0 - elevation * elevation));
        float3 direction = normalize(
            normal * elevation +
            (tangent * cos(angle) + bitangent * sin(angle)) * sinElevation);

        float stepLength = kFirstStep;
        float marched = stepLength;
        bool rayOccluded = false;
        [loop]
        for (uint step = 0; step < kStepCount; ++step) {
            float3 samplePosition = origin + direction * marched;
            float2 sampleUV;
            float sampleViewDepth;
            if (!projectToScreenUV(camera, samplePosition, aspect,
                                   sampleUV, sampleViewDepth))
                break; // behind the camera: ray leaves the screen model
            if (any(sampleUV < 0.0) || any(sampleUV > 1.0))
                break; // offscreen: energy silently lost (by design)

            float4 storedPositionDepth = gPositionDepth.SampleLevel(
                gLinearClamp, sampleUV, 0);
            float storedViewDepth = storedPositionDepth.w;
            if (storedViewDepth > 0.0 &&
                sampleViewDepth > storedViewDepth + kDepthBias &&
                sampleViewDepth < storedViewDepth + kThickness) {
                // Screen-space hit: recycle that pixel's direct radiance.
                float3 hitRadiance = gDirect.SampleLevel(
                    gLinearClamp, sampleUV, 0).rgb;
                float3 hitNormal = gNormal.SampleLevel(
                    gLinearClamp, sampleUV, 0).xyz;
                float facing = saturate(dot(hitNormal, -direction));
                float cosine = saturate(dot(normal, direction));
                gathered += hitRadiance * (facing * cosine);
                rayOccluded = true;
                break;
            }
            stepLength *= kStepGrowth;
            marched += stepLength;
        }
        if (rayOccluded)
            occlusion += 1.0;
        else
            gathered += skyColor(direction) *
                        saturate(dot(normal, direction)) * 0.5;
    }

    float ambientOcclusion = 1.0 - occlusion / kRayCount;
    gOutIndirect[id.xy] = float4(gathered * (2.0 * kPi / kRayCount) * 0.5,
                                 ambientOcclusion);
}
