#include "prt_common.hlsli"

// PRT step 2: build this frame's environment SH (4 texels, RGB each).
//
// Deliberately a separate tiny pass: the whole PRT contract is that
// transfer (geometry, static, expensive) and light (dynamic, cheap) live on
// opposite sides of a multiply. This pass is the cheap side.

RWTexture2D<float4> gEnvironmentSH : register(u0);

[numthreads(4, 1, 1)]
void csEnvironment(uint3 id : SV_DispatchThreadID) {
    if (id.x >= kPRTEnvCoefficientCount)
        return;
    gEnvironmentSH[uint2(id.x, 0)] =
        prtEnvironmentSH(id.x, prtEnvLobeDirection());
}
