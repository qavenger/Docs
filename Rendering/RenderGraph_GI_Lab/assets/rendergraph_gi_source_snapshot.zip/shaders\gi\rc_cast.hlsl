#include "rc_common.hlsli"

// RC step 1: cast the ray interval of one cascade.
//
// Every thread owns one (probe, direction) pair and marches ONLY the radial
// interval [rcIntervalStart, rcIntervalEnd) assigned to its cascade. Nearby
// light transport is resolved by dense probes with few directions, far
// transport by sparse probes with many directions - that split is the whole
// radiance cascades idea.
//
// Output texel: rgb = radiance collected inside the interval,
//               a   = transmittance (1 = the interval saw nothing).
// dimensions.x = cascade index.

RWTexture2D<float4> gCastResult : register(u0);

[numthreads(8, 8, 1)]
void csCast(uint3 id : SV_DispatchThreadID) {
    if (any(id.xy >= kRCAtlasSize))
        return;

    uint cascade = gGI.dimensions.x;
    uint sqrtDirections = rcSqrtDirections(cascade);
    uint2 probeIndex = id.xy / sqrtDirections;
    uint2 directionTile = id.xy % sqrtDirections;
    uint directionIndex = directionTile.y * sqrtDirections + directionTile.x;

    float2 origin = rcProbeWorld(cascade, probeIndex);
    float2 direction = rcDirection(cascade, directionIndex);
    float intervalStart = rcIntervalStart(cascade);
    float intervalEnd = rcIntervalEnd(cascade);

    // Probes inside solid geometry cast nothing and stay opaque so upper
    // cascades cannot leak through them at merge time.
    if (rcSliceScene(origin).distance < 0.0) {
        gCastResult[id.xy] = float4(0.0, 0.0, 0.0, 0.0);
        return;
    }

    float travelled = intervalStart;
    float3 radiance = 0.0;
    float transmittance = 1.0;
    [loop]
    for (uint step = 0; step < 48 && travelled < intervalEnd; ++step) {
        float2 position = origin + direction * travelled;
        float emitterDistance = rcEmitterDistance(position);
        float sceneDistance = rcSliceScene(position).distance;

        if (emitterDistance < 0.012) {
            // Hit the disk emitter: collect its radiance, ray ends.
            radiance = gGI.lightColorTime.rgb *
                       (gGI.lightPositionIntensity.w * 0.55);
            transmittance = 0.0;
            break;
        }
        if (sceneDistance < 0.012) {
            // Hit an occluder boundary: it re-emits its bounce color
            // (albedo * in-plane direct light), then blocks the ray.
            SceneSample surface = rcSliceScene(position);
            float2 normal = rcSliceNormal(position);
            radiance = surface.albedo * rcDirectLight2D(
                position + normal * 0.03, normal);
            transmittance = 0.0;
            break;
        }
        travelled += clamp(min(sceneDistance, emitterDistance) * 0.82,
                           0.012, 0.5);
    }
    gCastResult[id.xy] = float4(radiance, transmittance);
}
