#pragma once

#include "../post_common.hlsli"

// Shared by every native Voxel GI workbench pass.
// The light is deliberately explicit: xyz is world-space position and this
// sample uses an isotropic point light, so there is no forward direction.
struct GIPush {
    float4 lightPositionIntensity; // xyz = world position, w = scalar intensity
    float4 lightColorTime;         // rgb = linear color, w = time in seconds
    float4 cameraPositionMode;     // xyz = camera position, w = debug view
    float4 volumeMinExtent;        // xyz = world-space minimum, w = cubic extent
    uint4 dimensions;              // source size, target size, output width, height
};
PUSH_CONSTANTS(GIPush, gGI);

static const float kPi = 3.14159265359;

float sdBox(float3 p, float3 center, float3 halfExtent) {
    float3 q = abs(p - center) - halfExtent;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float sdSphere(float3 p, float3 center, float radius) {
    return length(p - center) - radius;
}

struct SceneSample {
    float distance;
    float3 albedo;
};

SceneSample sampleAnalyticScene(float3 p) {
    SceneSample result;
    result.distance = 1e5;
    result.albedo = float3(0.55, 0.58, 0.62);

    float d = sdBox(p, float3(0.0, -0.22, 0.0), float3(4.0, 0.22, 4.0));
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.56, 0.58, 0.62);
    }

    d = sdBox(p, float3(0.0, 1.35, -3.72), float3(4.0, 1.55, 0.20));
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.54, 0.58, 0.64);
    }

    d = sdBox(p, float3(-3.72, 1.35, 0.0), float3(0.20, 1.55, 4.0));
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.62, 0.23, 0.18);
    }

    d = sdBox(p, float3(3.72, 1.35, 0.0), float3(0.20, 1.55, 4.0));
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.18, 0.28, 0.64);
    }

    d = sdBox(p, float3(0.15, 0.85, -0.15), float3(0.72, 0.85, 0.72));
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.82, 0.47, 0.16);
    }

    d = sdSphere(p, float3(1.85, 0.72, -0.65), 0.72);
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.18, 0.67, 0.55);
    }

    d = sdBox(p, float3(-1.60, 0.50, -1.55), float3(0.45, 0.50, 0.45));
    if (d < result.distance) {
        result.distance = d;
        result.albedo = float3(0.72, 0.20, 0.45);
    }
    return result;
}

float3 sceneNormal(float3 p) {
    const float epsilon = 0.012;
    float dx = sampleAnalyticScene(p + float3(epsilon, 0, 0)).distance -
               sampleAnalyticScene(p - float3(epsilon, 0, 0)).distance;
    float dy = sampleAnalyticScene(p + float3(0, epsilon, 0)).distance -
               sampleAnalyticScene(p - float3(0, epsilon, 0)).distance;
    float dz = sampleAnalyticScene(p + float3(0, 0, epsilon)).distance -
               sampleAnalyticScene(p - float3(0, 0, epsilon)).distance;
    return normalize(float3(dx, dy, dz));
}

bool visibleToPointLight(float3 surfacePosition, float3 surfaceNormal) {
    float3 toLight = gGI.lightPositionIntensity.xyz - surfacePosition;
    float maximumDistance = length(toLight);
    float3 direction = toLight / max(maximumDistance, 1e-4);
    float distance = 0.055;
    float3 origin = surfacePosition + surfaceNormal * 0.045;

    [loop]
    for (uint step = 0; step < 40 && distance < maximumDistance - 0.08; ++step) {
        float3 position = origin + direction * distance;
        float sceneDistance = sampleAnalyticScene(position).distance;
        if (sceneDistance < 0.018)
            return false;
        distance += clamp(sceneDistance * 0.72, 0.018, 0.28);
    }
    return true;
}

float3 evaluateDirectDiffuse(float3 position, float3 normal, float3 albedo) {
    float3 toLight = gGI.lightPositionIntensity.xyz - position;
    float distanceSquared = max(dot(toLight, toLight), 0.04);
    float3 lightDirection = toLight * rsqrt(distanceSquared);
    float nDotL = saturate(dot(normal, lightDirection));
    float attenuation = 1.0 / (1.0 + 0.11 * distanceSquared);
    float visibility = visibleToPointLight(position, normal) ? 1.0 : 0.0;
    return albedo * gGI.lightColorTime.rgb *
           (gGI.lightPositionIntensity.w * attenuation * nDotL * visibility / kPi);
}

float3 worldToVolumeUV(float3 worldPosition) {
    return (worldPosition - gGI.volumeMinExtent.xyz) / gGI.volumeMinExtent.w;
}

bool insideVolume(float3 uvw) {
    return all(uvw >= 0.0) && all(uvw <= 1.0);
}

// --- Shared workbench camera -------------------------------------------------
// Every scheme resolves primary visibility with the same analytic pinhole
// camera so that voxel/RSM/SSGI/probe outputs stay directly comparable.

static const float kCameraScreenScale = 0.72;

struct CameraBasis {
    float3 position;
    float3 forward;
    float3 right;
    float3 up;
};

CameraBasis makeWorkbenchCamera() {
    CameraBasis camera;
    camera.position = gGI.cameraPositionMode.xyz;
    float3 target = float3(0.0, 0.75, -0.25);
    camera.forward = normalize(target - camera.position);
    camera.right = normalize(cross(camera.forward, float3(0, 1, 0)));
    camera.up = normalize(cross(camera.right, camera.forward));
    return camera;
}

float3 cameraRayDirection(CameraBasis camera, float2 uv, float aspect) {
    float2 screen = uv * 2.0 - 1.0;
    screen.y = -screen.y;
    return normalize(camera.forward +
                     camera.right * screen.x * aspect * kCameraScreenScale +
                     camera.up * screen.y * kCameraScreenScale);
}

// Inverse of cameraRayDirection: world position -> uv + forward-axis distance.
// Returns false when the point is behind the camera.
bool projectToScreenUV(CameraBasis camera, float3 worldPosition, float aspect,
                       out float2 uv, out float viewDepth) {
    float3 offset = worldPosition - camera.position;
    viewDepth = dot(offset, camera.forward);
    uv = 0.0;
    if (viewDepth < 1e-3)
        return false;
    float x = dot(offset, camera.right);
    float y = dot(offset, camera.up);
    float2 screen;
    screen.x = x / (viewDepth * kCameraScreenScale * aspect);
    screen.y = y / (viewDepth * kCameraScreenScale);
    screen.y = -screen.y;
    uv = screen * 0.5 + 0.5;
    return true;
}

bool traceCameraRay(float3 origin, float3 direction,
                    out float3 hitPosition, out float3 hitNormal,
                    out float3 albedo) {
    float distance = 0.02;
    hitPosition = origin;
    hitNormal = float3(0, 1, 0);
    albedo = 0.0;
    [loop]
    for (uint step = 0; step < 96 && distance < 18.0; ++step) {
        hitPosition = origin + direction * distance;
        SceneSample scene = sampleAnalyticScene(hitPosition);
        if (scene.distance < 0.006) {
            hitNormal = sceneNormal(hitPosition);
            albedo = scene.albedo;
            return true;
        }
        distance += clamp(scene.distance * 0.76, 0.006, 0.25);
    }
    return false;
}

float3 skyColor(float3 direction) {
    float horizon = saturate(direction.y * 0.5 + 0.5);
    return lerp(float3(0.018, 0.025, 0.038),
                float3(0.11, 0.16, 0.23), horizon);
}

// Point-to-point SDF visibility used by probe resolve weights and by any
// scheme that wants a ground-truth-style occlusion query against the
// analytic scene.
bool segmentVisible(float3 fromPosition, float3 toPosition) {
    float3 offset = toPosition - fromPosition;
    float maximumDistance = length(offset);
    if (maximumDistance < 1e-4)
        return true;
    float3 direction = offset / maximumDistance;
    float distance = 0.06;
    [loop]
    for (uint step = 0; step < 40 && distance < maximumDistance - 0.07; ++step) {
        float3 position = fromPosition + direction * distance;
        float sceneDistance = sampleAnalyticScene(position).distance;
        if (sceneDistance < 0.018)
            return false;
        distance += clamp(sceneDistance * 0.72, 0.018, 0.28);
    }
    return true;
}
