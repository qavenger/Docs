#include "rsm_common.hlsli"

// RSM gather. Primary visibility comes from the shared workbench camera
// (identical to every other scheme); the indirect term importance-samples
// the RSM around the shading point's light-space projection, exactly like
// Dachsbacher & Stamminger 2005:
//
//   E_p(x, n) = flux_p * max(0, np . (x - xp)) * max(0, n . (xp - x))
//               / ||x - xp||^4
//
// Known and *intended* limitation, kept for teaching: VPL-to-receiver
// visibility is NOT tested, so RSM leaks through thin walls. The docs module
// compares this against schemes that do handle occlusion.
//
// View modes (cameraPositionMode.w):
//   0 = final (direct + indirect + ambient)
//   1 = RSM flux map (light view debug)
//   2 = RSM position/depth map (light view debug)
//   3 = indirect only

Texture2D<float4> gRSMPositionDepth : register(t0);
Texture2D<float4> gRSMNormal : register(t1);
Texture2D<float4> gRSMFlux : register(t2);
RWTexture2D<float4> gResolveTarget : register(u0);
SamplerState gLinearClamp : register(s0);

static const uint kVPLSampleCount = 96;
static const float kSampleRadiusUV = 0.34;
// Empirical normalization folding the per-texel solid angle of the RSM
// frustum into the gather sum; calibrated so the indirect-only view sits in
// the same exposure range as the voxel cone tracing scheme.
static const float kRSMFluxScale = 14.0;

float3 gatherRSMIndirect(float3 position, float3 normal) {
    CameraBasis light = makeRSMLightCamera();
    float2 centerUV;
    if (!projectToRSMUV(light, position, centerUV))
        centerUV = 0.5; // behind the light: fall back to frustum center

    float3 irradiance = 0.0;
    [loop]
    for (uint index = 0; index < kVPLSampleCount; ++index) {
        // Importance disk: density ~ 1/r, compensated by the r^2 weight.
        float xi1 = (float(index) + 0.5) / kVPLSampleCount;
        float xi2 = radicalInverseBase2(index);
        float radius = xi1 * kSampleRadiusUV;
        float angle = xi2 * 2.0 * kPi;
        float2 sampleUV = centerUV + radius * float2(sin(angle), cos(angle));
        if (any(sampleUV < 0.0) || any(sampleUV > 1.0))
            continue;

        float4 vplPosition = gRSMPositionDepth.SampleLevel(
            gLinearClamp, sampleUV, 0);
        if (vplPosition.w <= 0.0)
            continue; // light ray escaped the scene
        float3 vplNormal = gRSMNormal.SampleLevel(
            gLinearClamp, sampleUV, 0).xyz;
        float3 vplFlux = gRSMFlux.SampleLevel(gLinearClamp, sampleUV, 0).rgb;

        float3 toReceiver = position - vplPosition.xyz;
        float distanceSquared = max(dot(toReceiver, toReceiver), 0.012);
        float3 direction = toReceiver * rsqrt(distanceSquared);
        float emitterCosine = saturate(dot(vplNormal, direction));
        float receiverCosine = saturate(dot(normal, -direction));
        float weight = xi1 * xi1; // compensates the 1/r sample density
        irradiance += vplFlux * (emitterCosine * receiverCosine * weight /
                                 (distanceSquared * distanceSquared));
    }
    return irradiance * (kRSMFluxScale * kSampleRadiusUV * kSampleRadiusUV *
                         2.0 * kPi / kVPLSampleCount);
}

[numthreads(8, 8, 1)]
void csResolve(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float debugMode = gGI.cameraPositionMode.w;
    if (debugMode > 0.5 && debugMode < 2.5) {
        // Light-view MRT debug: what the RSM actually stores.
        float4 flux = gRSMFlux.SampleLevel(gLinearClamp, uv, 0);
        float4 positionDepth = gRSMPositionDepth.SampleLevel(
            gLinearClamp, uv, 0);
        float3 debugColor = debugMode < 1.5
            ? flux.rgb * 0.16
            : saturate(positionDepth.www / kRSMMaxRayDistance).xxx;
        gResolveTarget[id.xy] = float4(debugColor, 1.0);
        return;
    }

    CameraBasis camera = makeWorkbenchCamera();
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);
    float3 direction = cameraRayDirection(camera, uv, aspect);

    float3 hitPosition;
    float3 hitNormal;
    float3 albedo;
    float3 color;
    if (!traceCameraRay(camera.position, direction,
                        hitPosition, hitNormal, albedo)) {
        // Indirect-only keeps the sky black so validation measures the
        // actual VPL gather, not the sky gradient.
        color = debugMode > 2.5 ? 0.0 : skyColor(direction);
    } else {
        float3 direct = evaluateDirectDiffuse(hitPosition, hitNormal, albedo);
        float3 indirect = albedo *
            gatherRSMIndirect(hitPosition + hitNormal * 0.03, hitNormal);
        color = debugMode > 2.5
            ? indirect * 1.9
            : direct + indirect + albedo * 0.015;
    }
    gResolveTarget[id.xy] = float4(color, 1.0);
}
