#include "rc_common.hlsli"

// RC step 3: resolve the merged cascade 0 into a top-down fluence map.
//
// Each screen pixel maps to a point in the slice domain; its fluence is the
// direction-average of merged cascade 0, bilinearly interpolated across the
// four surrounding probes. Geometry is overlaid so shadows, penumbrae and
// colored bounce read against the scene that produced them. This preview is
// intentionally a top-down 2D map - the same presentation the docs module
// uses - not a fake 3D render.
//
// View modes (cameraPositionMode.w):
//   0 = fluence + geometry overlay (final)
//   1 = cast-only cascade 0 (no merge - shows what merging contributes)
//   2 = raw merged cascade-0 atlas (the actual data structure)
//   3 = fluence only, no overlays (validation measures the merged field)

Texture2D<float4> gMergedCascade0 : register(t0); // merged C0
Texture2D<float4> gCastCascade0 : register(t1);   // cast-only C0
RWTexture2D<float4> gResolveTarget : register(u0);

float3 sampleFluence(Texture2D<float4> atlas, float2 planePosition) {
    uint probeCount = rcProbeCount(0);
    uint sqrtDirections = rcSqrtDirections(0);
    float2 gridCoordinate =
        (planePosition - kRCDomainMin) / kRCDomainExtent * probeCount - 0.5;
    float2 clamped = clamp(gridCoordinate, 0.0, float(probeCount) - 1.001);
    uint2 base = uint2(clamped);
    float2 fraction = saturate(clamped - float2(base));

    float3 fluence = 0.0;
    [unroll]
    for (uint corner = 0; corner < 4; ++corner) {
        uint2 offset = uint2(corner & 1, corner >> 1);
        uint2 probeIndex = min(base + offset, probeCount - 1);
        float2 bilinear = lerp(1.0 - fraction, fraction, float2(offset));
        float weight = bilinear.x * bilinear.y;

        float3 directionSum = 0.0;
        [unroll]
        for (uint direction = 0; direction < 4; ++direction) {
            uint2 tile = uint2(direction % sqrtDirections,
                               direction / sqrtDirections);
            directionSum += atlas.Load(
                int3(probeIndex * sqrtDirections + tile, 0)).rgb;
        }
        fluence += directionSum * (0.25 * weight);
    }
    return fluence;
}

[numthreads(8, 8, 1)]
void csResolve(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float debugMode = gGI.cameraPositionMode.w;

    if (debugMode > 1.5 && debugMode < 2.5) {
        // Raw atlas view: the merged cascade-0 texture as stored.
        uint2 atlasTexel = uint2(uv * kRCAtlasSize);
        float4 texel = gMergedCascade0.Load(int3(atlasTexel, 0));
        gResolveTarget[id.xy] = float4(texel.rgb * 1.4, 1.0);
        return;
    }

    // Full-screen stretch of the square domain (teaching map, not a render).
    float2 planePosition = kRCDomainMin +
        float2(uv.x, 1.0 - uv.y) * kRCDomainExtent;

    bool castOnly = debugMode > 0.5 && debugMode < 1.5;
    float3 fluence = castOnly
        ? sampleFluence(gCastCascade0, planePosition)
        : sampleFluence(gMergedCascade0, planePosition);
    float3 color = fluence * 1.35;

    if (!(debugMode > 2.5)) {
        // Geometry + emitter overlays for the final and cast-only views.
        SceneSample slice = rcSliceScene(planePosition);
        if (rcEmitterDistance(planePosition) < 0.0) {
            color = gGI.lightColorTime.rgb *
                    (gGI.lightPositionIntensity.w * 0.55);
        } else if (slice.distance < 0.0) {
            color = slice.albedo * 0.16 + color * 0.22;
        } else if (slice.distance < 0.045) {
            color += slice.albedo * 0.25; // thin outline
        }
    }
    gResolveTarget[id.xy] = float4(color, 1.0);
}
