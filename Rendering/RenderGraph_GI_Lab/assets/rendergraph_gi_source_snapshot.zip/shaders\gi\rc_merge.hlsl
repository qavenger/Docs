#include "rc_common.hlsli"

// RC step 2: merge cascade N with the already-merged cascade N+1.
//
//   merged_N(probe, dir) = cast_N(probe, dir).rgb
//     + cast_N(probe, dir).a * bilinear_probes( avg_4_child_dirs(
//           merged_{N+1}) )
//
// The interval's transmittance gates the far field: if the near interval hit
// something, nothing from behind it leaks through. Probe interpolation uses
// the four surrounding parent probes; direction refinement averages the four
// child directions that subdivide this direction's angular bin.
// dimensions.x = cascade index N (the one being merged INTO).

Texture2D<float4> gCastCurrent : register(t0);   // cast_N
Texture2D<float4> gMergedCoarser : register(t1); // merged_{N+1}
RWTexture2D<float4> gMergedResult : register(u0);

float4 loadCoarser(uint cascade, uint2 parentProbe, uint parentDirection) {
    uint sqrtDirections = rcSqrtDirections(cascade + 1);
    uint2 tile = uint2(parentDirection % sqrtDirections,
                       parentDirection / sqrtDirections);
    return gMergedCoarser.Load(
        int3(parentProbe * sqrtDirections + tile, 0));
}

[numthreads(8, 8, 1)]
void csMerge(uint3 id : SV_DispatchThreadID) {
    if (any(id.xy >= kRCAtlasSize))
        return;

    uint cascade = gGI.dimensions.x;
    uint sqrtDirections = rcSqrtDirections(cascade);
    uint2 probeIndex = id.xy / sqrtDirections;
    uint2 directionTile = id.xy % sqrtDirections;
    uint directionIndex = directionTile.y * sqrtDirections + directionTile.x;

    float4 nearField = gCastCurrent.Load(int3(id.xy, 0));
    if (nearField.a <= 0.0) {
        gMergedResult[id.xy] = nearField;
        return;
    }

    // Four surrounding parent probes with bilinear weights.
    uint parentCount = rcProbeCount(cascade + 1);
    float2 parentCoordinate =
        (float2(probeIndex) + 0.5) * 0.5 - 0.5; // child->parent grid
    float2 clamped = clamp(parentCoordinate, 0.0, float(parentCount) - 1.001);
    uint2 parentBase = uint2(clamped);
    float2 fraction = saturate(clamped - float2(parentBase));

    float3 farField = 0.0;
    [unroll]
    for (uint corner = 0; corner < 4; ++corner) {
        uint2 offset = uint2(corner & 1, corner >> 1);
        uint2 parentProbe = min(parentBase + offset, parentCount - 1);
        float2 bilinear = lerp(1.0 - fraction, fraction, float2(offset));
        float weight = bilinear.x * bilinear.y;

        // Average the four child directions of this angular bin.
        float3 parentRadiance = 0.0;
        [unroll]
        for (uint child = 0; child < 4; ++child) {
            parentRadiance += loadCoarser(
                cascade, parentProbe, directionIndex * 4 + child).rgb;
        }
        farField += parentRadiance * (0.25 * weight);
    }

    gMergedResult[id.xy] = float4(
        nearField.rgb + nearField.a * farField, nearField.a);
}
