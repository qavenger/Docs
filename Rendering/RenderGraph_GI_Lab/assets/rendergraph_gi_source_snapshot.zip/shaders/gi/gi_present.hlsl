#include "../post_common.hlsli"

Texture2D<float4> gHDRInput : register(t0);
SamplerState gLinearClamp : register(s0);

FullscreenVSOut vsMain(uint vertexId : SV_VertexID) {
    return fullscreenTriangle(vertexId);
}

float3 acesFilm(float3 x) {
    return saturate((x * (2.51 * x + 0.03)) /
                    (x * (2.43 * x + 0.59) + 0.14));
}

float4 psPresent(FullscreenVSOut input) : SV_Target0 {
    float3 hdr = gHDRInput.Sample(gLinearClamp, input.uv).rgb;
    return float4(acesFilm(hdr), 1.0);
}
