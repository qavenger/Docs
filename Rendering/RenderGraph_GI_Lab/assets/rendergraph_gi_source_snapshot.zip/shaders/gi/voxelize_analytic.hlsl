#include "voxel_gi_common.hlsli"

RWTexture3D<float4> gVoxelLevel0 : register(u0);

[numthreads(4, 4, 4)]
void csVoxelize(uint3 id : SV_DispatchThreadID) {
    uint dimension = gGI.dimensions.y;
    if (any(id >= dimension))
        return;

    float cellSize = gGI.volumeMinExtent.w / dimension;
    float3 uvw = (float3(id) + 0.5) / dimension;
    float3 worldPosition = gGI.volumeMinExtent.xyz + uvw * gGI.volumeMinExtent.w;
    SceneSample scene = sampleAnalyticScene(worldPosition);

    // A one-voxel conservative shell around each analytic surface.
    // This is a real GPU volume build, but it intentionally is not called
    // triangle conservative rasterization.
    float opacity = saturate(1.0 - abs(scene.distance) / (cellSize * 0.92));
    float3 radiance = 0.0;
    if (opacity > 0.001) {
        float3 normal = sceneNormal(worldPosition);
        float3 projected = worldPosition - normal * scene.distance;
        radiance = evaluateDirectDiffuse(projected, normal, scene.albedo);
    }
    gVoxelLevel0[id] = float4(radiance, opacity);
}
