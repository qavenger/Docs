#include "voxel_gi_common.hlsli"

Texture3D<float4> gVoxelLevel0 : register(t0);
Texture3D<float4> gVoxelLevel1 : register(t1);
Texture3D<float4> gVoxelLevel2 : register(t2);
Texture3D<float4> gVoxelLevel3 : register(t3);
RWTexture2D<float4> gResolveTarget : register(u0);
SamplerState gLinearClamp3D : register(s0);

float4 sampleVolumeLevel(float3 uvw, uint level) {
    if (!insideVolume(uvw))
        return 0.0;
    if (level == 0) return gVoxelLevel0.SampleLevel(gLinearClamp3D, uvw, 0);
    if (level == 1) return gVoxelLevel1.SampleLevel(gLinearClamp3D, uvw, 0);
    if (level == 2) return gVoxelLevel2.SampleLevel(gLinearClamp3D, uvw, 0);
    return gVoxelLevel3.SampleLevel(gLinearClamp3D, uvw, 0);
}

float4 sampleVolume(float3 worldPosition, float continuousLod) {
    float3 uvw = worldToVolumeUV(worldPosition);
    float lod = clamp(continuousLod, 0.0, 3.0);
    uint low = (uint)floor(lod);
    uint high = min(low + 1, 3u);
    return lerp(sampleVolumeLevel(uvw, low),
                sampleVolumeLevel(uvw, high),
                frac(lod));
}

float3 traceCone(float3 origin, float3 direction, float aperture) {
    float baseCell = gGI.volumeMinExtent.w / max((float)gGI.dimensions.x, 1.0);
    float distance = baseCell * 1.35;
    float transmittance = 1.0;
    float3 accumulated = 0.0;

    [loop]
    for (uint step = 0; step < 24 && transmittance > 0.025; ++step) {
        float diameter = max(baseCell, 2.0 * tan(aperture * 0.5) * distance);
        float lod = log2(max(diameter / baseCell, 1.0));
        float4 voxel = sampleVolume(origin + direction * distance, lod);
        float opacity = saturate(voxel.a);
        accumulated += transmittance * voxel.rgb * opacity;
        transmittance *= 1.0 - opacity;
        distance += max(baseCell * 0.65, diameter * 0.48);
        if (distance > gGI.volumeMinExtent.w * 1.35)
            break;
    }
    return accumulated;
}

float3 diffuseConeSet(float3 position, float3 normal) {
    float3 helper = abs(normal.y) < 0.96 ? float3(0, 1, 0) : float3(1, 0, 0);
    float3 tangent = normalize(cross(helper, normal));
    float3 bitangent = normalize(cross(normal, tangent));
    const float spread = 0.72;
    float3 sum = traceCone(position, normal, 0.72) * 0.28;
    sum += traceCone(position, normalize(normal + tangent * spread), 0.82) * 0.18;
    sum += traceCone(position, normalize(normal - tangent * spread), 0.82) * 0.18;
    sum += traceCone(position, normalize(normal + bitangent * spread), 0.82) * 0.18;
    sum += traceCone(position, normalize(normal - bitangent * spread), 0.82) * 0.18;
    return sum;
}

bool traceCamera(float3 origin, float3 direction,
                 out float3 hitPosition, out float3 hitNormal, out float3 albedo) {
    float distance = 0.02;
    [loop]
    for (uint step = 0; step < 96 && distance < 18.0; ++step) {
        hitPosition = origin + direction * distance;
        SceneSample scene = sampleAnalyticScene(hitPosition);
        if (scene.distance < 0.006) {
            hitNormal = sceneNormal(hitPosition);
            albedo = scene.albedo;
            return true;
        }
        distance += clamp(scene.distance * 0.76, 0.006, 0.25);
    }
    return false;
}

float3 skyColor(float3 direction) {
    float horizon = saturate(direction.y * 0.5 + 0.5);
    return lerp(float3(0.018, 0.025, 0.038),
                float3(0.11, 0.16, 0.23), horizon);
}

[numthreads(8, 8, 1)]
void csResolve(uint3 id : SV_DispatchThreadID) {
    uint2 outputSize = gGI.dimensions.zw;
    if (any(id.xy >= outputSize))
        return;

    float2 uv = (float2(id.xy) + 0.5) / outputSize;
    float debugMode = gGI.cameraPositionMode.w;
    if (debugMode > 0.5 && debugMode < 2.5) {
        float3 uvw = float3(uv.x, 0.31, 1.0 - uv.y);
        float4 voxel = sampleVolumeLevel(uvw, 0);
        float3 debugColor = debugMode < 1.5 ? voxel.aaa : voxel.rgb * 1.8;
        gResolveTarget[id.xy] = float4(debugColor, 1.0);
        return;
    }

    float3 cameraPosition = gGI.cameraPositionMode.xyz;
    float3 cameraTarget = float3(0.0, 0.75, -0.25);
    float3 forward = normalize(cameraTarget - cameraPosition);
    float3 right = normalize(cross(forward, float3(0, 1, 0)));
    float3 up = normalize(cross(right, forward));
    float aspect = (float)outputSize.x / max((float)outputSize.y, 1.0);
    float2 screen = uv * 2.0 - 1.0;
    screen.y = -screen.y;
    float3 direction = normalize(forward + right * screen.x * aspect * 0.72 + up * screen.y * 0.72);

    float3 hitPosition;
    float3 hitNormal;
    float3 albedo;
    float3 color;
    if (!traceCamera(cameraPosition, direction, hitPosition, hitNormal, albedo)) {
        color = skyColor(direction);
    } else {
        float3 direct = evaluateDirectDiffuse(hitPosition, hitNormal, albedo);
        float baseCell = gGI.volumeMinExtent.w / max((float)gGI.dimensions.x, 1.0);
        float3 indirectIncoming = diffuseConeSet(hitPosition + hitNormal * baseCell * 1.35, hitNormal);
        float3 indirect = albedo * indirectIncoming;
        color = debugMode > 2.5 ? indirect * 1.9 : direct + indirect + albedo * 0.015;
    }
    gResolveTarget[id.xy] = float4(color, 1.0);
}
