#include "voxel_gi_common.hlsli"

Texture3D<float4> gSourceVolume : register(t0);
RWTexture3D<float4> gTargetVolume : register(u0);

[numthreads(4, 4, 4)]
void csDownsample(uint3 id : SV_DispatchThreadID) {
    uint targetSize = gGI.dimensions.y;
    if (any(id >= targetSize))
        return;

    uint3 sourceBase = id * 2;
    float3 weightedRadiance = 0.0;
    float opacityWeight = 0.0;
    float remainingTransmittance = 1.0;

    [unroll]
    for (uint z = 0; z < 2; ++z) {
        [unroll]
        for (uint y = 0; y < 2; ++y) {
            [unroll]
            for (uint x = 0; x < 2; ++x) {
                float4 sampleValue = gSourceVolume.Load(int4(sourceBase + uint3(x, y, z), 0));
                weightedRadiance += sampleValue.rgb * sampleValue.a;
                opacityWeight += sampleValue.a;
                remainingTransmittance *= 1.0 - saturate(sampleValue.a);
            }
        }
    }

    float3 radiance = weightedRadiance / max(opacityWeight, 1e-4);
    float opacity = 1.0 - remainingTransmittance;
    gTargetVolume[id] = float4(radiance, opacity);
}
