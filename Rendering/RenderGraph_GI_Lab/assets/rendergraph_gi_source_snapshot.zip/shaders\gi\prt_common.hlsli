#pragma once

#include "probe_common.hlsli"

// PRT teaching-lite shared pieces.
//
// The docs module's core distinction: probes cache an ANSWER (irradiance),
// PRT caches a TRANSFER OPERATOR - how any environment light turns into
// received light at a point, with the scene's occlusion baked in. Here the
// operator is an SH-L1 visibility transfer per probe of the same 8x4x8
// grid: T_lm = sum_dirs V(dir) * Y_lm(dir) * dOmega. The environment is a
// separate tiny SH build each frame (sky + a distant lobe that follows the
// animated point light so relighting is visibly dynamic).
//
// Teaching-lite boundaries, stated: relighting multiplies T and L per SH
// coefficient (band-limited approximation, exact only for L1-band lights);
// transfer is visibility-only (no interreflection operator); the transfer
// bake reruns every frame for validation determinism even though a real
// system would bake once offline - the point is WHERE occlusion lives, not
// when it is computed.

// Environment SH texture: 4 texels (c0, c1x, c1y, c1z), RGB per texel.
static const uint kPRTEnvCoefficientCount = 4;

// Distant-lobe direction for the animated point light, as seen from the
// room center - the "sun proxy" that makes PRT relighting move.
float3 prtEnvLobeDirection() {
    float3 center = float3(0.0, 0.8, 0.0);
    return normalize(gGI.lightPositionIntensity.xyz - center);
}

// Analytic environment SH-L1 for one color channel set (returns c0,c1x,c1y,c1z
// packed per float4 texel at build time; evaluation reconstructs radiance).
float4 prtEnvironmentSH(uint coefficient, float3 lobeDirection) {
    // Sky: matches skyColor() gradient projected to L1 by hand:
    // average color in c0, vertical gradient in c1y.
    const float3 skyAverage = float3(0.064, 0.0925, 0.134);
    const float3 skyGradient = float3(0.046, 0.0675, 0.096);
    // Distant lobe: light color, modest weight so sky stays visible.
    float3 lobeColor = gGI.lightColorTime.rgb *
                       (gGI.lightPositionIntensity.w * 0.055);

    float4 basisLobe = shEvaluateL1(lobeDirection);
    if (coefficient == 0)
        return float4(skyAverage * 2.0 * sqrt(kPi) * 0.282095 +
                      lobeColor * basisLobe.x, 1.0);
    if (coefficient == 1)
        return float4(lobeColor * basisLobe.y, 1.0);
    if (coefficient == 2)
        return float4(skyGradient * 0.65 + lobeColor * basisLobe.z, 1.0);
    return float4(lobeColor * basisLobe.w, 1.0);
}
