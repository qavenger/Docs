// Native, cross-backend Voxel GI workbench.
//
// Actual frame graph:
//   Voxelize.AnalyticScene -> VoxelMip.L1 -> L2 -> L3
//   -> ConeTrace.Resolve -> Present
//
// The sample intentionally uses an analytic SDF scene for deterministic GPU
// voxelization. It does not claim to implement conservative triangle raster.
// Every frame rebuilds the complete volume from the current point light:
// history reads = 0, which makes fast light motion an explicit validation case.

#include "../common/sample_common.h"

#include <rg/runtime/window.h>

#include <algorithm>
#include <chrono>
#include <fstream>
#include <numeric>
#include <vector>

using namespace rg;
using namespace samples;

namespace {

constexpr u32 kVoxelSize = 32;
constexpr u32 kMipCount = 4;

struct GIPush {
    f32 lightPositionIntensity[4];
    f32 lightColorTime[4];
    f32 cameraPositionMode[4];
    f32 volumeMinExtent[4];
    u32 dimensions[4];
};
static_assert(sizeof(GIPush) == 80);

struct Pipelines {
    std::shared_ptr<rhi::IPipeline> voxelize;
    std::shared_ptr<rhi::IPipeline> downsample;
    std::shared_ptr<rhi::IPipeline> resolve;
    std::shared_ptr<rhi::IPipeline> present;
    std::shared_ptr<rhi::ISampler> linearClamp3D;
};

Pipelines createPipelines(rhi::IDevice* device, rhi::Format outputFormat,
                          shader::TargetIL targetIL) {
    shader::ShaderCompiler compiler;
    const std::filesystem::path shaderDir = RG_SHADER_DIR;
    const auto compileCompute = [&](const char* file, const char* entry) {
        auto shaderBlob = compiler.compileOrDie({
            .sourcePath = shaderDir / "gi" / file,
            .entryPoint = entry,
            .stage = rhi::ShaderStage::Compute,
            .target = targetIL,
        });
        rhi::ComputePipelineDesc desc;
        desc.name = std::string(file) + ":" + entry;
        desc.computeShader = std::move(shaderBlob);
        return device->createComputePipeline(desc);
    };

    Pipelines pipelines;
    pipelines.voxelize = compileCompute("voxelize_analytic.hlsl", "csVoxelize");
    pipelines.downsample = compileCompute("voxel_mip.hlsl", "csDownsample");
    pipelines.resolve = compileCompute("voxel_cone_resolve.hlsl", "csResolve");
    {
        auto vs = compiler.compileOrDie({
            .sourcePath = shaderDir / "gi" / "gi_present.hlsl",
            .entryPoint = "vsMain",
            .stage = rhi::ShaderStage::Vertex,
            .target = targetIL,
        });
        auto ps = compiler.compileOrDie({
            .sourcePath = shaderDir / "gi" / "gi_present.hlsl",
            .entryPoint = "psPresent",
            .stage = rhi::ShaderStage::Pixel,
            .target = targetIL,
        });
        rhi::GraphicsPipelineDesc desc;
        desc.name = "GI.Present";
        desc.vertexShader = std::move(vs);
        desc.pixelShader = std::move(ps);
        desc.rasterizer.cull = rhi::CullMode::None;
        desc.renderTargetFormats = { outputFormat };
        pipelines.present = device->createGraphicsPipeline(desc);
    }
    pipelines.linearClamp3D = device->createSampler({
        .filter = rhi::FilterMode::Linear,
        .addressU = rhi::AddressMode::Clamp,
        .addressV = rhi::AddressMode::Clamp,
        .addressW = rhi::AddressMode::Clamp,
    });
    return pipelines;
}

GIPush makePush(f32 time, f32 viewMode, u32 outputWidth, u32 outputHeight) {
    // Isotropic point light. Position is animated; forward is intentionally
    // absent because it has no directional cone.
    const f32 lightX = -2.35f + 4.55f * (0.5f + 0.5f * std::sin(time * 1.73f));
    const f32 lightZ = 1.55f + 1.15f * std::sin(time * 1.11f + 0.7f);
    GIPush push{};
    push.lightPositionIntensity[0] = lightX;
    push.lightPositionIntensity[1] = 2.45f;
    push.lightPositionIntensity[2] = lightZ;
    push.lightPositionIntensity[3] = 7.5f;
    push.lightColorTime[0] = 1.0f;
    push.lightColorTime[1] = 0.76f;
    push.lightColorTime[2] = 0.42f;
    push.lightColorTime[3] = time;
    push.cameraPositionMode[0] = 0.0f;
    push.cameraPositionMode[1] = 3.25f;
    push.cameraPositionMode[2] = 7.15f;
    push.cameraPositionMode[3] = viewMode;
    push.volumeMinExtent[0] = -4.0f;
    push.volumeMinExtent[1] = -0.45f;
    push.volumeMinExtent[2] = -4.0f;
    push.volumeMinExtent[3] = 8.0f;
    push.dimensions[0] = kVoxelSize;
    push.dimensions[1] = kVoxelSize;
    push.dimensions[2] = outputWidth;
    push.dimensions[3] = outputHeight;
    return push;
}

rdg::RenderGraph::Stats buildAndExecute(
        rhi::IDevice* device, rdg::TransientPool& transientPool,
        rhi::ICommandList* commandList, const Pipelines& pipelines,
        rhi::ITexture* finalTarget, rhi::ResourceState targetCurrentState,
        rhi::ResourceState targetFinalState, f32 time, f32 viewMode) {
    rdg::RenderGraph graph(device, &transientPool);
    const auto& outputDesc = finalTarget->desc();
    auto push = makePush(time, viewMode, outputDesc.width, outputDesc.height);

    std::array<rdg::RGTexture, kMipCount> volumes;
    for (u32 level = 0; level < kMipCount; ++level) {
        const u32 size = kVoxelSize >> level;
        volumes[level] = graph.createTexture({
            .name = "GI.Voxel.L" + std::to_string(level),
            .dimension = rhi::TextureDimension::Tex3D,
            .width = size,
            .height = size,
            .depthOrArraySize = size,
            .format = rhi::Format::RGBA16_FLOAT,
            .usage = rhi::TextureUsage::UnorderedAccess |
                     rhi::TextureUsage::ShaderResource,
        });
    }
    auto resolvedHDR = graph.createTexture({
        .name = "GI.ResolvedHDR",
        .width = outputDesc.width,
        .height = outputDesc.height,
        .format = rhi::Format::RGBA16_FLOAT,
        .usage = rhi::TextureUsage::UnorderedAccess |
                 rhi::TextureUsage::ShaderResource,
    });
    auto finalTexture = graph.importTexture(
        finalTarget, targetCurrentState, targetFinalState);

    graph.addPass("GI.01 Voxelize Analytic Scene", rdg::PassFlags::Compute,
                  [&, voxelL0 = volumes[0], push](rdg::PassBuilder& builder) {
        builder.writeTexture(voxelL0);
        auto pipeline = pipelines.voxelize;
        GIPush passPush = push;
        passPush.dimensions[0] = kVoxelSize;
        passPush.dimensions[1] = kVoxelSize;
        return [voxelL0, pipeline, passPush](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureUAV(0, 0, context.texture(voxelL0));
            context.cmd().setPushConstants(&passPush, sizeof(passPush));
            context.cmd().dispatch((kVoxelSize + 3) / 4,
                                   (kVoxelSize + 3) / 4,
                                   (kVoxelSize + 3) / 4);
        };
    });

    for (u32 level = 1; level < kMipCount; ++level) {
        const auto source = volumes[level - 1];
        const auto target = volumes[level];
        const u32 sourceSize = kVoxelSize >> (level - 1);
        const u32 targetSize = kVoxelSize >> level;
        const std::string passName = "GI.0" + std::to_string(level + 1) +
                                     " Voxel Mip L" + std::to_string(level);
        graph.addPass(passName, rdg::PassFlags::Compute,
                      [&, source, target, sourceSize, targetSize, push](rdg::PassBuilder& builder) {
            builder.readTexture(source);
            builder.writeTexture(target);
            auto pipeline = pipelines.downsample;
            GIPush passPush = push;
            passPush.dimensions[0] = sourceSize;
            passPush.dimensions[1] = targetSize;
            return [source, target, pipeline, passPush, targetSize](rdg::PassContext& context) {
                context.cmd().setPipeline(pipeline.get());
                context.cmd().setTextureSRV(0, 0, context.texture(source));
                context.cmd().setTextureUAV(0, 0, context.texture(target));
                context.cmd().setPushConstants(&passPush, sizeof(passPush));
                context.cmd().dispatch((targetSize + 3) / 4,
                                       (targetSize + 3) / 4,
                                       (targetSize + 3) / 4);
            };
        });
    }

    graph.addPass("GI.05 Multi-Cone Resolve", rdg::PassFlags::Compute,
                  [&, resolvedHDR, volumes, push](rdg::PassBuilder& builder) {
        for (const auto volume : volumes)
            builder.readTexture(volume);
        builder.writeTexture(resolvedHDR);
        auto pipeline = pipelines.resolve;
        auto sampler = pipelines.linearClamp3D;
        return [resolvedHDR, volumes, pipeline, sampler, push](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            for (u32 level = 0; level < kMipCount; ++level)
                context.cmd().setTextureSRV(0, level, context.texture(volumes[level]));
            context.cmd().setTextureUAV(0, 0, context.texture(resolvedHDR));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().setPushConstants(&push, sizeof(push));
            context.cmd().dispatch((push.dimensions[2] + 7) / 8,
                                   (push.dimensions[3] + 7) / 8, 1);
        };
    });

    graph.addPass("GI.06 Present", rdg::PassFlags::Raster,
                  [&, resolvedHDR, finalTexture](rdg::PassBuilder& builder) {
        builder.readTexture(resolvedHDR);
        builder.colorTarget(0, finalTexture, rhi::LoadOp::DontCare);
        auto pipeline = pipelines.present;
        auto sampler = pipelines.linearClamp3D;
        return [resolvedHDR, pipeline, sampler](rdg::PassContext& context) {
            context.cmd().setPipeline(pipeline.get());
            context.cmd().setTextureSRV(0, 0, context.texture(resolvedHDR));
            context.cmd().setSampler(0, 0, sampler.get());
            context.cmd().draw(3);
        };
    });

    graph.setOutput(finalTexture);
    return graph.execute(commandList);
}

struct FrameMetrics {
    f64 meanLuma = 0;
    u64 hash = 1469598103934665603ull;
    u32 nonBlackPixels = 0;
};

FrameMetrics measureRGBA8(const u8* pixels, u32 width, u32 height, u32 rowPitch) {
    FrameMetrics metrics;
    f64 lumaSum = 0;
    for (u32 y = 0; y < height; ++y) {
        const u8* row = pixels + u64(y) * rowPitch;
        for (u32 x = 0; x < width; ++x) {
            const u8* pixel = row + x * 4;
            const f64 luma = pixel[0] * 0.2126 +
                             pixel[1] * 0.7152 +
                             pixel[2] * 0.0722;
            lumaSum += luma;
            if (pixel[0] + pixel[1] + pixel[2] > 12)
                ++metrics.nonBlackPixels;
            for (u32 channel = 0; channel < 4; ++channel) {
                metrics.hash ^= pixel[channel];
                metrics.hash *= 1099511628211ull;
            }
        }
    }
    metrics.meanLuma = lumaSum / (width * height);
    return metrics;
}

void writeBmpRGBA8(const std::filesystem::path& path,
                   const u8* pixels, u32 width, u32 height, u32 rowPitch) {
    const u32 pixelBytes = width * height * 4;
    const u32 fileBytes = 54 + pixelBytes;
    std::array<u8, 54> header{};
    header[0] = 'B';
    header[1] = 'M';
    auto writeU32 = [&](u32 offset, u32 value) {
        for (u32 byte = 0; byte < 4; ++byte)
            header[offset + byte] = u8(value >> (byte * 8));
    };
    writeU32(2, fileBytes);
    writeU32(10, 54);
    writeU32(14, 40);
    writeU32(18, width);
    writeU32(22, height);
    header[26] = 1;
    header[28] = 32;
    writeU32(34, pixelBytes);

    std::ofstream stream(path, std::ios::binary);
    const std::string createError =
        "cannot create capture " + path.string();
    RG_CHECK(stream.good(), createError.c_str());
    stream.write(reinterpret_cast<const char*>(header.data()), header.size());
    std::vector<u8> bgra(width * 4);
    for (u32 outputY = 0; outputY < height; ++outputY) {
        const u32 sourceY = height - 1 - outputY;
        const u8* source = pixels + u64(sourceY) * rowPitch;
        for (u32 x = 0; x < width; ++x) {
            bgra[x * 4 + 0] = source[x * 4 + 2];
            bgra[x * 4 + 1] = source[x * 4 + 1];
            bgra[x * 4 + 2] = source[x * 4 + 0];
            bgra[x * 4 + 3] = 255;
        }
        stream.write(reinterpret_cast<const char*>(bgra.data()), bgra.size());
    }
    const std::string writeError =
        "failed to write capture " + path.string();
    RG_CHECK(stream.good(), writeError.c_str());
    RG_LOG_INFO("wrote native GPU preview: {}", path.string());
}

int runValidation(rhi::IDevice* device, shader::TargetIL targetIL,
                  const std::filesystem::path& capturePath) {
    constexpr u32 width = 320;
    constexpr u32 height = 180;
    const u32 rowPitch = (width * 4 + 255) & ~255u;
    auto pipelines = createPipelines(
        device, rhi::Format::RGBA8_UNORM, targetIL);
    rdg::TransientPool transientPool(device);
    auto readback = device->createBuffer({
        .name = "GI.Validation.Readback",
        .size = u64(rowPitch) * height,
        .memory = rhi::MemoryType::Readback,
    });

    constexpr u32 validationViewCount = 3;
    const f32 times[validationViewCount] = { 0.0f, 1.83f, 0.0f };
    const f32 viewModes[validationViewCount] = { 0.0f, 0.0f, 3.0f };
    const char* viewLabels[validationViewCount] = {
        "final-frame0", "final-frame1", "indirect-only"
    };
    FrameMetrics metrics[validationViewCount];
    rdg::RenderGraph::Stats stats{};
    for (u32 frame = 0; frame < validationViewCount; ++frame) {
        auto target = device->createTexture({
            .name = "GI.Validation.Target",
            .width = width,
            .height = height,
            .format = rhi::Format::RGBA8_UNORM,
            .usage = rhi::TextureUsage::RenderTarget |
                     rhi::TextureUsage::CopySrc,
        });
        auto* commandList = device->beginFrame();
        stats = buildAndExecute(
            device, transientPool, commandList, pipelines, target.get(),
            rhi::ResourceState::Common, rhi::ResourceState::CopySrc,
            times[frame], viewModes[frame]);
        commandList->copyTextureToBuffer(
            readback.get(), 0, target.get(), 0);
        device->endFrame(nullptr);
        device->waitIdle();
        transientPool.tick();

        const auto* pixels = static_cast<const u8*>(readback->map());
        metrics[frame] = measureRGBA8(
            pixels, width, height, rowPitch);
        if (frame == 0 && !capturePath.empty()) {
            writeBmpRGBA8(capturePath, pixels, width, height, rowPitch);
        } else if (frame == 2 && !capturePath.empty()) {
            auto indirectPath = capturePath;
            indirectPath.replace_filename(
                capturePath.stem().string() + "_indirect" +
                capturePath.extension().string());
            writeBmpRGBA8(indirectPath, pixels, width, height, rowPitch);
        }
        readback->unmap();
        RG_LOG_INFO(
            "[{}] lightTime={:.2f} meanLuma={:.3f} "
            "nonBlack={}/{} hash={}",
            viewLabels[frame], times[frame], metrics[frame].meanLuma,
            metrics[frame].nonBlackPixels, width * height,
            metrics[frame].hash);
    }

    const bool graphOk =
        stats.totalPasses == 6 &&
        stats.culledPasses == 0 &&
        stats.transientTextures == 5 &&
        stats.barriers >= 9;
    const bool imageOk =
        metrics[0].meanLuma > 4.0 &&
        metrics[0].nonBlackPixels > width * height * 8 / 10;
    const bool motionOk =
        metrics[0].hash != metrics[1].hash &&
        std::abs(metrics[0].meanLuma - metrics[1].meanLuma) > 0.02;
    const bool indirectOk =
        metrics[2].meanLuma > 0.10 &&
        metrics[2].nonBlackPixels > width * height / 20 &&
        metrics[2].hash != metrics[0].hash;

    RG_LOG_INFO(
        "stats: passes={} culled={} transientTex={} barriers={}",
        stats.totalPasses, stats.culledPasses,
        stats.transientTextures, stats.barriers);
    RG_LOG_INFO(
        "checks: graph={} image={} movingLight={} indirectOnly={} "
        "historyReads=0",
        graphOk, imageOk, motionOk, indirectOk);
    if (graphOk && imageOk && motionOk && indirectOk) {
        RG_LOG_INFO(
            "VALIDATION PASSED (native Voxel GI, current-frame rebuild)");
        return 0;
    }
    RG_LOG_ERROR("VALIDATION FAILED");
    return 1;
}

f32 parseViewMode(int argc, char** argv) {
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument = argv[index];
        if (argument == "--view=occupancy") return 1.0f;
        if (argument == "--view=radiance") return 2.0f;
        if (argument == "--view=indirect") return 3.0f;
    }
    return 0.0f;
}

std::filesystem::path parseCapturePath(int argc, char** argv) {
    constexpr std::string_view prefix = "--capture-bmp=";
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument = argv[index];
        if (argument.starts_with(prefix))
            return std::filesystem::path(argument.substr(prefix.size()));
    }
    return {};
}

const char* viewName(f32 viewMode) {
    if (viewMode > 2.5f) return "Indirect Only";
    if (viewMode > 1.5f) return "Radiance Slice";
    if (viewMode > 0.5f) return "Occupancy Slice";
    return "Final GI";
}

} // namespace

int main(int argc, char** argv) {
    SampleApp app = SampleApp::create(argc, argv);
    auto device = std::move(app.device);
    if (app.validate)
        return runValidation(
            device.get(), app.targetIL, parseCapturePath(argc, argv));

    const f32 viewMode = parseViewMode(argc, argv);
    const std::string title =
        std::string("RenderGraph 08 - Native Voxel GI [") +
        viewName(viewMode) + "] [" +
        (app.useVulkan ? "Vulkan" : "D3D12") + "]";
    runtime::Window window({
        .title = title,
        .width = 1280,
        .height = 720,
    });
    auto swapChain = device->createSwapChain({
        .windowHandle = window.nativeHandle(),
        .width = window.width(),
        .height = window.height(),
        .format = rhi::Format::BGRA8_UNORM,
    });
    auto pipelines = createPipelines(
        device.get(), rhi::Format::BGRA8_UNORM, app.targetIL);
    rdg::TransientPool transientPool(device.get());
    const auto start = std::chrono::steady_clock::now();
    u64 frameCount = 0;

    RG_LOG_INFO(
        "view={} | pointLight position animates in world space | "
        "forward=N/A (isotropic) | historyReads=0",
        viewName(viewMode));
    while (window.pumpMessages()) {
        if (window.wasResized()) {
            device->waitIdle();
            swapChain->resize(window.width(), window.height());
        }
        if (window.width() == 0 || window.height() == 0)
            continue;

        const f32 time = std::chrono::duration<f32>(
            std::chrono::steady_clock::now() - start).count();
        auto* commandList = device->beginFrame();
        const auto stats = buildAndExecute(
            device.get(), transientPool, commandList, pipelines,
            swapChain->currentBackBuffer(),
            rhi::ResourceState::Present,
            rhi::ResourceState::Present,
            time, viewMode);
        device->endFrame(swapChain.get());
        transientPool.tick();
        if (frameCount == 0) {
            RG_LOG_INFO(
                "frame0: passes={} culled={} transientTex={} barriers={}",
                stats.totalPasses, stats.culledPasses,
                stats.transientTextures, stats.barriers);
        }
        ++frameCount;
    }
    device->waitIdle();
    RG_LOG_INFO("exited after {} frames", frameCount);
    return 0;
}
