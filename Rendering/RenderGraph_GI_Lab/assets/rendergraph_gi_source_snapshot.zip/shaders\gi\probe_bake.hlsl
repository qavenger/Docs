#include "probe_common.hlsli"

// Probe bake: one thread per probe. Each probe shoots kProbeRayCount
// Fibonacci-sphere rays against the analytic SDF, evaluates the radiance it
// sees in that direction (direct diffuse at the hit, sky on a miss) and
// projects the result onto SH-L1.
//
// The whole grid is rebuilt every frame from the current light position -
// history reads = 0, matching the voxel scheme's fast-light validation case.

RWTexture3D<float4> gProbeSHRed : register(u0);
RWTexture3D<float4> gProbeSHGreen : register(u1);
RWTexture3D<float4> gProbeSHBlue : register(u2);

float3 probeRayRadiance(float3 origin, float3 direction) {
    float distance = 0.03;
    [loop]
    for (uint step = 0; step < 72 && distance < 15.0; ++step) {
        float3 position = origin + direction * distance;
        SceneSample scene = sampleAnalyticScene(position);
        if (scene.distance < 0.008) {
            float3 normal = sceneNormal(position);
            float3 surface = position - normal * scene.distance;
            return evaluateDirectDiffuse(surface, normal, scene.albedo);
        }
        distance += clamp(scene.distance * 0.78, 0.008, 0.30);
    }
    return skyColor(direction);
}

[numthreads(4, 4, 4)]
void csBake(uint3 id : SV_DispatchThreadID) {
    if (any(id >= kProbeGridSize))
        return;

    float3 origin = probeWorldPosition(id);
    float4 shRed = 0.0;
    float4 shGreen = 0.0;
    float4 shBlue = 0.0;

    [loop]
    for (uint ray = 0; ray < kProbeRayCount; ++ray) {
        float3 direction = fibonacciSphereDirection(ray, kProbeRayCount);
        float3 radiance = probeRayRadiance(origin, direction);
        float4 basis = shEvaluateL1(direction);
        shRed += basis * radiance.r;
        shGreen += basis * radiance.g;
        shBlue += basis * radiance.b;
    }

    // Monte Carlo over the sphere: 4*pi / N.
    float normalization = 4.0 * kPi / kProbeRayCount;
    gProbeSHRed[id] = shRed * normalization;
    gProbeSHGreen[id] = shGreen * normalization;
    gProbeSHBlue[id] = shBlue * normalization;
}
