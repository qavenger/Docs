#include "prt_common.hlsli"

// PRT step 1: bake the visibility transfer operator per probe.
//
// One thread per probe, 64 Fibonacci rays: a ray that escapes the scene
// contributes its SH basis to the transfer vector; a blocked ray does not.
// The result says "this location receives environment light from these
// directions" - answer-agnostic, reusable under ANY environment.
// A real system bakes this once offline (static geometry); the workbench
// reruns it per frame only to keep the validation harness uniform.

RWTexture3D<float4> gTransfer : register(u0); // (T0, T1x, T1y, T1z), scalar

[numthreads(4, 4, 4)]
void csBake(uint3 id : SV_DispatchThreadID) {
    if (any(id >= kProbeGridSize))
        return;

    float3 origin = probeWorldPosition(id);
    float4 transfer = 0.0;

    [loop]
    for (uint ray = 0; ray < kProbeRayCount; ++ray) {
        float3 direction = fibonacciSphereDirection(ray, kProbeRayCount);
        float travelled = 0.03;
        bool blocked = false;
        [loop]
        for (uint step = 0; step < 72 && travelled < 14.0; ++step) {
            float3 position = origin + direction * travelled;
            SceneSample scene = sampleAnalyticScene(position);
            if (scene.distance < 0.008) {
                blocked = true;
                break;
            }
            travelled += clamp(scene.distance * 0.78, 0.008, 0.30);
        }
        if (!blocked)
            transfer += shEvaluateL1(direction);
    }

    gTransfer[id] = transfer * (4.0 * kPi / kProbeRayCount);
}
